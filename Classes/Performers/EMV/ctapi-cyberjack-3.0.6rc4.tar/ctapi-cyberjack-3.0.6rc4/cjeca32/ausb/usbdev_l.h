

#ifndef USBDEV_L_H
#define USBDEV_L_H

#include <inttypes.h>



typedef struct rsct_usbdev_t rsct_usbdev_t;
struct rsct_usbdev_t {
  rsct_usbdev_t *next;
  char path[256];
  char serial[128];
  uint32_t busId;
  uint32_t busPos;
  uint32_t vendorId;
  uint32_t productId;
};


#ifdef __cplusplus
extern "C" {
#endif

rsct_usbdev_t *rsct_usbdev_new();
void rsct_usbdev_free(rsct_usbdev_t *d);

void rsct_usbdev_list_add(rsct_usbdev_t **head, rsct_usbdev_t *d);
void rsct_usbdev_list_free(rsct_usbdev_t *d);


int rsct_usbdev_scan(rsct_usbdev_t **devList);

int rsct_enum_serials(const char *fname);

int rsct_get_serial_for_port(int port,
			     const char *fname,
			     char *sbuff,
			     int blen);
int rsct_get_port_for_serial(const char *fname,
			     const char *serial);


#ifdef __cplusplus
}
#endif


#endif
