/* USB support for the Cyberjack family of readers.
 *
 * Previous version were (C) 2004-2005 by Harald Welte <laforge@gnumonks.org>
 * This version is a rewrite (asynchronous USB is no longer needed).
 *
 * (C) 2007 Martin Preuss <martin@libchipcard.de>
 *
 * Distributed and licensed under the terms of GNU LGPL, Version 2.1
 */


#ifndef _AUSB_H
#define _AUSB_H


#include <usb.h>
#include <inttypes.h>



#define AUSB_CYBERJACK_VENDOR_ID 0xc4b



typedef struct ausb_dev_handle ausb_dev_handle;

/* virtual functions */
typedef void (*AUSB_CLOSE_FN)(ausb_dev_handle *ah);
typedef int (*AUSB_START_INTERRUPT_FN)(ausb_dev_handle *ah, int ep);
typedef int (*AUSB_STOP_INTERRUPT_FN)(ausb_dev_handle *ah);
typedef int (*AUSB_BULK_WRITE_FN)(ausb_dev_handle *ah, int ep,
				  char *bytes, int size,
				  int timeout);
typedef int (*AUSB_BULK_READ_FN)(ausb_dev_handle *ah, int ep,
				 char *bytes, int size,
				 int timeout);

typedef void (*AUSB_LOG_FN)(ausb_dev_handle *ah,
			    const char *text,
			    const void *pData, uint32_t ulDataLen);


typedef void (*AUSB_CALLBACK)(const uint8_t *data,
			      uint32_t dlength,
			      void *userdata);


/* structures */
struct ausb_callback {
  AUSB_CALLBACK handler;
  void *userdata;
};


struct ausb_dev_handle {
  usb_dev_handle *uh;
  struct ausb_callback cb;
  void *extraData;
  uint16_t pid;

  AUSB_CLOSE_FN closeFn;
  AUSB_START_INTERRUPT_FN startInterruptFn;
  AUSB_STOP_INTERRUPT_FN stopInterruptFn;
  AUSB_BULK_WRITE_FN bulkWriteFn;
  AUSB_BULK_READ_FN bulkReadFn;
};



#ifdef __cplusplus
extern "C" {
#endif



/** @name Functions used commonly by all implementations
 */
/*@{*/

/* intitialization */ 
int ausb_init(void);

struct usb_device *ausb_get_dev_by_idx(int num);

struct usb_device *ausb_get_dev_by_bus_pos(int busId, int devId);

struct usb_device *ausb_get_dev_by_name(const char *devName);

/**
 * Register a callback which is called as soon as an URB request is
 * finished.
 * @param ah ausb handle obtained via @ref ausb_open
 * @param callback callback function to be used. This function receives a
 *  pointer to the received interrupt data and caller-specified user data
 * @param userdata userdata to be passed to the callback function
 */
int ausb_register_callback(ausb_dev_handle *ah,
			   AUSB_CALLBACK callback,
			   void *userdata);

int ausb_claim_interface(ausb_dev_handle *ah, int interface);
int ausb_release_interface(ausb_dev_handle *ah, int interface);
int ausb_set_configuration(ausb_dev_handle *dev, int configuration);

#ifdef LIBUSB_HAS_GET_DRIVER_NP
int ausb_get_driver_np(ausb_dev_handle *ah, int interface, char *name,
		       unsigned int namelen);
#endif
#ifdef LIBUSB_HAS_DETACH_KERNEL_DRIVER_NP
int ausb_detach_kernel_driver_np(ausb_dev_handle *dev, int interface);
int ausb_reattach_kernel_driver_np(ausb_dev_handle *dev, int interface);
#endif

int ausb_reset(ausb_dev_handle *ah);
int ausb_clear_halt(ausb_dev_handle *ah, unsigned int ep);
int ausb_reset_endpoint(ausb_dev_handle *ah, unsigned int ep);

int ausb_reset_pipe(ausb_dev_handle *ah, int ep);

void ausb_set_log_fn(AUSB_LOG_FN fn);

void ausb_log(ausb_dev_handle *ah, const char *text,
	      const void *pData, uint32_t ulDataLen);

/*@}*/


int ausb1_extend(ausb_dev_handle *ah);
#ifdef USE_THREADS
int ausb2_extend(ausb_dev_handle *ah);
#endif
int ausb3_extend(ausb_dev_handle *ah);

int ausb_get_fd(ausb_dev_handle *ah);


/** @name Functions which are implemented differently for
 * different configurations.
 */
/*@{*/
/**
 * Open the given USB device. This creates the necessary
 * ausb handle which must be free'd when it is no longer
 * needed by calling @ref ausb_close.
 * @return ausb handle to be used by other functions in this group
 * @param dev usb device object obtained from libusb
 *
 */
ausb_dev_handle *ausb_open(struct usb_device *dev, int t);


int ausb_close(ausb_dev_handle *ah);

int ausb_start_interrupt(ausb_dev_handle *ah, int ep);
int ausb_stop_interrupt(ausb_dev_handle *ah);

int ausb_bulk_write(ausb_dev_handle *ah, int ep, char *bytes, int size,
		    int timeout);
int ausb_bulk_read(ausb_dev_handle *ah, int ep, char *bytes, int size, 
		   int timeout);

/*@}*/

#ifdef __cplusplus
}
#endif


#endif /* _AUSB_H */


