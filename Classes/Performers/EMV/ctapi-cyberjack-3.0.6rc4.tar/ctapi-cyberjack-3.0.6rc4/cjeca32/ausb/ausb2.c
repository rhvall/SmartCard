/* USB support for the Cyberjack family of readers.
 *
 * Previous versions were (C) 2004-2005 by Harald Welte <laforge@gnumonks.org>
 * This version is a rewrite (asynchronous USB is no longer needed).
 *
 * (C) 2007 Martin Preuss <martin@libchipcard.de>
 *
 * Distributed and licensed under the terms of GNU LGPL, Version 2.1
 */

/*
 * This implementation use a thread for any open reader to catch any interrupt
 * URB.
 *
 * This implementation otherwise only uses plain libusb calls so it should
 * work on any system for which libusb an libpthread is available.
 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif


/* only compile this module if threads are to be used */
#ifdef USE_THREADS


#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <usb.h>

#include <pthread.h>

#include "ausb_l.h"

#define DEBUGP(ah, format, ...) { \
  char dbg_buffer[256]; \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: " format  , __LINE__ , ##__VA_ARGS__ ); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, NULL, 0); \
}


#define DEBUGL(ah, text, pData, ulDataLen) {\
  char dbg_buffer[256]; \
  \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: %s", __LINE__ , text); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, pData, ulDataLen);\
}



struct ausb2_extra {
  int intEp;
  pthread_t intThread;
  pthread_mutex_t intMutex;
  int stopIntThread;
  int intThreadRunning;
};
typedef struct ausb2_extra ausb2_extra;





static void *ausb2_interrupt_thread(void *p) {
  ausb_dev_handle *ah;
  ausb2_extra *xh;
  uint8_t intBuffer[4096];
  int rv;

  ah=(ausb_dev_handle*)p;
  xh=(ausb2_extra*)ah->extraData;

  fprintf(stderr, "Interrupt thread started\n");
  while(1) {
    do {
      pthread_mutex_lock(&xh->intMutex);
      if (xh->stopIntThread) {
	xh->intThreadRunning=0;
	pthread_mutex_unlock(&xh->intMutex);
	fprintf(stderr, "Interrupt thread stopped (1)\n");
	pthread_exit((void*)0);
      }
      pthread_mutex_unlock(&xh->intMutex);

      /*fprintf(stderr, "INT-THREAD: Waiting for interrupt\n");*/
      rv=usb_interrupt_read(ah->uh, xh->intEp,
			    (char*)intBuffer,
			    sizeof(intBuffer),
			    500);
    } while (rv < 0 && (errno == EINTR || errno==EAGAIN));
    if (rv<0) {
      pthread_mutex_lock(&xh->intMutex);
      xh->intThreadRunning=0;
      pthread_mutex_unlock(&xh->intMutex);
      fprintf(stderr, "Interrupt thread stopped (2) [%d, %s]\n",
	      errno, strerror(errno));
      pthread_exit((void*)0);
    }
    else {
      fprintf(stderr, "INT-THREAD: Got an interrupt (%d)\n", rv);
      if (ah->cb.handler) {
        fprintf(stderr, "Calling interrupt handler...\n");
	ah->cb.handler(intBuffer, rv, ah->cb.userdata);
	fprintf(stderr, "Calling interrupt handler...done\n");
      }
    }
  }

}



static int ausb2_start_interrupt(ausb_dev_handle *ah, int ep) {
  ausb2_extra *xh;

  xh=(ausb2_extra*)ah->extraData;

  xh->intEp=ep;

  pthread_mutex_lock(&xh->intMutex);
  if (xh->intThreadRunning) {
    pthread_mutex_unlock(&xh->intMutex);
    DEBUGP(NULL, "interrupt thread is already running\n");
    return -1;
  }
  xh->stopIntThread=0;
  pthread_mutex_unlock(&xh->intMutex);

  if (pthread_create(&xh->intThread, NULL, ausb2_interrupt_thread, ah)) {
    DEBUGP(NULL, "could not start interrupt thread\n");
    fprintf(stderr, "ERROR: %s\n", strerror(errno));
    return -1;
  }

  pthread_mutex_lock(&xh->intMutex);
  xh->intThreadRunning=1;
  pthread_mutex_unlock(&xh->intMutex);

  return 0;
}



static int ausb2_stop_interrupt(ausb_dev_handle *ah) {
  ausb2_extra *xh;

  xh=(ausb2_extra*)ah->extraData;

  pthread_mutex_lock(&xh->intMutex);
  if (!xh->intThreadRunning) {
    pthread_mutex_unlock(&xh->intMutex);
    DEBUGP(NULL, "interrupt thread is not running\n");
    return -1;
  }
  pthread_mutex_unlock(&xh->intMutex);

  DEBUGP(NULL, "Stopping interrupt thread");
  pthread_mutex_lock(&xh->intMutex);
  xh->stopIntThread=1;
  pthread_mutex_unlock(&xh->intMutex);
  pthread_join(xh->intThread, NULL);
  return 0;
}



static int ausb2_bulk_write(ausb_dev_handle *ah, int ep,
			    char *bytes, int length,
			    int timeout){
  int rv;
  ausb2_extra *xh;

  xh=(ausb2_extra*)ah->extraData;

  do {
    /* check whether interrupt thread is still active */
    pthread_mutex_lock(&xh->intMutex);
    if (!xh->intThreadRunning) {
      pthread_mutex_unlock(&xh->intMutex);
      DEBUGP(NULL,"interrupt thread has been stopped, error");
      return -1;
    }
    pthread_mutex_unlock(&xh->intMutex);

    rv=usb_bulk_write(ah->uh, ep, bytes, length, timeout);
  } while (rv < 0 && errno == EINTR);
  return rv;
}



static int ausb2_bulk_read(ausb_dev_handle *ah, int ep,
			   char *bytes, int size,
			   int timeout){
  int rv;
  ausb2_extra *xh;

  xh=(ausb2_extra*)ah->extraData;

  do {
    /* check whether interrupt thread is still active */
    pthread_mutex_lock(&xh->intMutex);
    if (!xh->intThreadRunning) {
      pthread_mutex_unlock(&xh->intMutex);
      DEBUGP(NULL,"interrupt thread has been stopped, error");
      return -1;
    }
    pthread_mutex_unlock(&xh->intMutex);

    rv=usb_bulk_read(ah->uh, ep, bytes, size, timeout);
  } while (rv < 0 && errno == EINTR);
  return rv;
}




static void ausb2_close(struct ausb_dev_handle *ah){
  ausb2_extra *xh;

  xh=(ausb2_extra*)ah->extraData;
  pthread_mutex_destroy(&xh->intMutex);
}



int ausb2_extend(ausb_dev_handle *ah) {
  ausb2_extra *xh;

  xh=(ausb2_extra*)malloc(sizeof(ausb2_extra));
  memset(xh, 0, sizeof(*xh));

  pthread_mutex_init(&xh->intMutex, NULL);

  ah->extraData=xh;
  ah->closeFn=ausb2_close;
  ah->startInterruptFn=ausb2_start_interrupt;
  ah->stopInterruptFn=ausb2_stop_interrupt;
  ah->bulkWriteFn=ausb2_bulk_write;
  ah->bulkReadFn=ausb2_bulk_read;

  return 0;
}


#endif


