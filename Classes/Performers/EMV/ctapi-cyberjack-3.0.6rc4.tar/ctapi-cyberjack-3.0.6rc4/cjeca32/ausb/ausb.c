/* USB support for the Cyberjack family of readers.
 *
 * Previous version were (C) 2004-2005 by Harald Welte <laforge@gnumonks.org>
 * This version is a rewrite (asynchronous USB is no longer needed).
 *
 * (C) 2007 Martin Preuss <martin@libchipcard.de>
 *
 * Distributed and licensed under the terms of GNU LGPL, Version 2.1
 */


#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <inttypes.h>

#include "ausb_l.h"

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <usb.h>
#include <time.h>


#ifdef CONFIG_COMPAT
#undef CONFIG_COMPAT
#endif
#ifndef __user
# define __user
#endif
#include <linux/usbdevice_fs.h>

#ifndef USBDEVFS_CONNECT
# define USBDEVFS_CONNECT _IO('U', 23)
#endif


#define DEBUGP(ah, format, ...) {\
  char dbg_buffer[256]; \
  \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: " format  , __LINE__ , ##__VA_ARGS__); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, NULL, 0);\
}


#define DEBUGL(ah, text, pData, ulDataLen) {\
  char dbg_buffer[256]; \
  \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: %s", __LINE__ , text); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, pData, ulDataLen);\
}



static int ausb_was_init=0;

static AUSB_LOG_FN ausb_log_fn=NULL;



void ausb_set_log_fn(AUSB_LOG_FN fn) {
  ausb_log_fn=fn;
}



void ausb_log(ausb_dev_handle *ah, const char *text,
	      const void *pData, uint32_t ulDataLen) {
  if (ausb_log_fn)
    ausb_log_fn(ah, text, pData, ulDataLen);
}



int ausb_get_fd(ausb_dev_handle *ah){
  return *((int *)ah->uh);
}



int ausb_init(void){
  if (!ausb_was_init) {
    usb_init();
    ausb_was_init=1;
  }

  usb_find_busses();
  usb_find_devices();
  return 1;
}



static struct usb_device *ausb__get_dev_by_idx(int num) {
  struct usb_bus *busses, *bus;
  struct usb_device *dev;
  int found = 0;

  ausb_init();

  busses = usb_get_busses();

  for (bus = busses; bus; bus = bus->next) {
    for (dev = bus->devices; dev; dev = dev->next) {
      if (dev->descriptor.idVendor == AUSB_CYBERJACK_VENDOR_ID) {
	found++;
	if (found == num)
	  return dev;
      }
    }
  }
  return NULL;
}



struct usb_device *ausb_get_dev_by_idx(int num) {
  time_t startTime;
  
  startTime=time(NULL);
  for (;;) {
    struct usb_device *dev;
    
    dev=ausb__get_dev_by_idx(num);
    if (dev)
      return dev;
    else {
      time_t thisTime;
      
      thisTime=time(NULL);
      if (difftime(thisTime, startTime)>5) {
	DEBUGP(NULL, "Device not found within 5 secs, giving up\n");
	return NULL;
      }
      sleep(1);
    }
  }
}



static struct usb_device *ausb__get_dev_by_bus_pos(int busId, int devId) {
  struct usb_bus *busses, *bus;
  struct usb_device *dev;
  char tname[PATH_MAX+1];
  char filename[PATH_MAX+1];
  int nlen;

  ausb_init();

  snprintf(tname, PATH_MAX, "%03d/%03d",
	   busId, devId);
  nlen=strlen(tname);

  busses = usb_get_busses();

  for (bus = busses; bus; bus = bus->next) {
    for (dev = bus->devices; dev; dev = dev->next) {
      int flen;

      strncpy(filename, bus->dirname, PATH_MAX );
      strncat(filename, "/", PATH_MAX );
      strncat(filename, dev->filename, PATH_MAX );
      flen=strlen(filename);
      if (flen>=nlen) {
	if (strncmp(filename+(flen-nlen), tname, nlen)==0) {
	  if (dev->descriptor.idVendor == AUSB_CYBERJACK_VENDOR_ID)
	    return dev;
	  else {
	    DEBUGP(NULL, "device at %03x:%03x is not a cyberjack", busId, devId);
	    return NULL;
	  }
	}
      }
    }
  }
  return NULL;
}



struct usb_device *ausb_get_dev_by_bus_pos(int busId, int devId) {
  time_t startTime;
  
  startTime=time(NULL);
  for (;;) {
    struct usb_device *dev;
    
    dev=ausb__get_dev_by_bus_pos(busId, devId);
    if (dev)
      return dev;
    else {
      time_t thisTime;
      
      thisTime=time(NULL);
      if (difftime(thisTime, startTime)>5) {
	DEBUGP(NULL, "Device not found within 5 secs, giving up\n");
	return NULL;
      }
      sleep(1);
    }
  }
}



static struct usb_device *ausb__get_dev_by_name(const char *devName) {
  struct usb_bus *busses, *bus;
  struct usb_device *dev;
  char filename[PATH_MAX+1];
  int nlen;
  unsigned int device_vendor, device_product;
  const char *devDir;
  const char *devFile;
  char namebuf[256];
  int i;

  ausb_init();

  /* get name of libusb device */
  if (strncmp("usb:", devName, 4) != 0) {
    DEBUGP(NULL, "Device name does not start with \"usb:\"\n");
    return NULL;
  }

  if (sscanf(devName, "usb:%x/%x", &device_vendor, &device_product) != 2){
    DEBUGP(NULL, "Unable to parse device name (1)\n");
    return NULL;
  }

  devDir=strstr(devName, "libusb:");
  if (devDir==NULL) {
    DEBUGP(NULL, "Unable to parse device name (2)\n");
    return NULL;
  }
  devDir+=7;

  devFile=strchr(devDir, ':');
  if (devFile==NULL) {
    DEBUGP(NULL, "Unable to parse device name (3)\n");
    return NULL;
  }
  i=devFile-devDir;
  if (i>=sizeof(namebuf)) {
    DEBUGP(NULL, "Device path too long (1)\n");
    return NULL;
  }
  devFile++;

  strncpy(namebuf, devDir, i);
  namebuf[i]=0;
  i=strlen(devFile);
  if ((strlen(namebuf)+i+2)>=sizeof(namebuf)) {
    DEBUGP(NULL, "Device path too long (2)\n");
    return NULL;
  }
  strcat(namebuf, "/");
  strcat(namebuf, devFile);

  /* now we got the bus/device name */
  filename[PATH_MAX]=0;


  nlen=strlen(namebuf);

  usb_find_busses();
  usb_find_devices();
  busses = usb_get_busses();

  for (bus = busses; bus; bus = bus->next) {
    for (dev = bus->devices; dev; dev = dev->next) {
      int flen;

      strncpy( filename, bus->dirname, PATH_MAX );
      strncat( filename, "/", PATH_MAX );
      strncat( filename, dev->filename, PATH_MAX );
      flen=strlen(filename);
      if (flen>=nlen) {
	if (strncmp(filename+(flen-nlen), namebuf, nlen)==0)
	  return dev;
      }
    }
  }
  return NULL;
}



struct usb_device *ausb_get_dev_by_name(const char *devName) {
  time_t startTime;
  
  startTime=time(NULL);
  for (;;) {
    struct usb_device *dev;
    
    dev=ausb__get_dev_by_name(devName);
    if (dev)
      return dev;
    else {
      time_t thisTime;
      
      thisTime=time(NULL);
      if (difftime(thisTime, startTime)>5) {
	DEBUGP(NULL, "Device not found within 5 secs, giving up\n");
	return NULL;
      }
      sleep(1);
    }
  }
}



int ausb_register_callback(ausb_dev_handle *ah,
			   AUSB_CALLBACK callback,
			   void *userdata){
  DEBUGP(ah, "registering callback:%p\n", callback);

  ah->cb.handler=callback;
  ah->cb.userdata=userdata;

  return 0;
}



int ausb_claim_interface(ausb_dev_handle *ah, int interface){
  DEBUGP(ah, "entering\n");
  return usb_claim_interface(ah->uh, interface);
}



int ausb_release_interface(ausb_dev_handle *ah, int interface){
  DEBUGP(ah, "entering\n");
  if (ausb_was_init<1) {
    DEBUGP(ah, "ausb subsystem has not been initialized!");
    return -1;
  }
  return usb_release_interface(ah->uh, interface);
}



int ausb_set_configuration(ausb_dev_handle *ah, int configuration){
  int ret;

  DEBUGP(ah, "entering\n");
  ret=usb_set_configuration(ah->uh, configuration);
  if (ret<0) {
    DEBUGP(ah, "usb_set_configuration returned %d (errno=%d:%s)\n", ret,
           errno, strerror(errno));
  }
  return ret;
}



#ifdef LIBUSB_HAS_GET_DRIVER_NP
int ausb_get_driver_np(ausb_dev_handle *ah, int interface, char *name,
		       unsigned int namelen){
  DEBUGP(ah, "entering\n");
  return usb_get_driver_np(ah->uh, interface, name, namelen);
}
#endif



#ifdef LIBUSB_HAS_DETACH_KERNEL_DRIVER_NP
int ausb_detach_kernel_driver_np(ausb_dev_handle *ah, int interface){
  DEBUGP(ah, "entering\n");
  return usb_detach_kernel_driver_np(ah->uh, interface);
}



int ausb_reattach_kernel_driver_np(ausb_dev_handle *ah, int interface){
  struct usbdevfs_ioctl command;
  int ret;

  command.ifno = interface;
  command.ioctl_code = USBDEVFS_CONNECT;
  command.data = NULL;

  ret=ioctl(ausb_get_fd(ah), USBDEVFS_IOCTL, &command);
  if (ret<0) {
    DEBUGP(ah, "IOCTL(USBDEVFS_CONNECT): %d (%s)\n",
	   errno, strerror(errno));
  }
  return ret;
}
#endif



void ausb_fini(void){
}



ausb_dev_handle *ausb_open(struct usb_device *dev, int t) {
  ausb_dev_handle *ah=NULL;
  int rv;

  /*fprintf(stderr, "Opening device...\n");*/
  ah=malloc(sizeof *ah);
  if (ah==0) {
    DEBUGP(ah, "memory full\n");
    return 0;
  }
  memset(ah, 0, sizeof(*ah));

  ah->pid=dev->descriptor.idProduct;

  ah->uh=usb_open(dev);
  if (!ah->uh) {
    DEBUGP(ah, "usb_open() failed\n");
    fprintf(stderr, "usb_open() failed (%d=%s)\n", errno, strerror(errno));
    free(ah);
    return NULL;
  }
  /*else {
    fprintf(stderr, "Device found\n");
  }*/

  switch(t) {
  case 1:
    rv=ausb1_extend(ah);
    break;

  case 2:
#ifdef USE_THREADS
    rv=ausb2_extend(ah);
#else
    DEBUGP(ah, "Support for threads is not compiled-in.\n");
    rv=-1;
#endif
    break;

  case 3:
    rv=ausb3_extend(ah);
    break;

  default:
    DEBUGP(ah, "Invalid type %d\n", t);
    rv=-1;
    break;
  }

  if (rv) {
    DEBUGP(ah, "Could not extend as type %d (%d)\n", t, rv);
    usb_close(ah->uh);
    free(ah);
    return 0;
  }

  return ah;
}



int ausb_close(ausb_dev_handle *ah) {
  if (ah->closeFn)
    ah->closeFn(ah);
  usb_close(ah->uh);
  free(ah);
  return 0;
}



int ausb_start_interrupt(ausb_dev_handle *ah, int ep) {
  if (ah->startInterruptFn)
    return ah->startInterruptFn(ah, ep);
  return 0;
}



int ausb_stop_interrupt(ausb_dev_handle *ah) {
  if (ah->stopInterruptFn)
    return ah->stopInterruptFn(ah);
  return 0;
}



int ausb_bulk_write(ausb_dev_handle *ah, int ep,
		    char *bytes, int size,
		    int timeout) {
  DEBUGL(ah, "Write:", bytes, size);

  if (ah->bulkWriteFn)
    return ah->bulkWriteFn(ah, ep, bytes, size, timeout);
  return -1;
}



int ausb_bulk_read(ausb_dev_handle *ah, int ep,
		   char *bytes, int size,
		   int timeout) {
  if (ah->bulkReadFn) {
    int rv;

    DEBUGP(ah, "Reading up to %d bytes", size);
    rv=ah->bulkReadFn(ah, ep, bytes, size, timeout);
    if (rv>=0) {
      DEBUGL(ah, "Read:", bytes, rv);
    }
    return rv;
  }
  return -1;
}



int ausb_reset(ausb_dev_handle *ah){
  return usb_reset(ah->uh);
}



int ausb_reset_endpoint(ausb_dev_handle *ah, unsigned int ep){
  return usb_resetep(ah->uh, ep);
}



int ausb_clear_halt(ausb_dev_handle *ah, unsigned int ep){
  return usb_clear_halt(ah->uh, ep);
}



int ausb_reset_pipe(ausb_dev_handle *ah, int ep){
  int rv;

  rv=usb_control_msg(ah->uh,
		     0x02, /* host to device */
		     0x03, /* set feature */
		     0x00, /* halt */
		     ep,   /* endpoint */
		     NULL, 0,
		     1200);
  if (rv<0) {
    DEBUGP(ah, "unable to reset endpoint %d (%d=%s)",ep,
	   errno, strerror(errno));
    return rv;
  }
  rv=usb_clear_halt(ah->uh, ep);
  if (rv<0) {
    DEBUGP(ah, "unable to start endpoint %d (%d=%s)",ep,
	   errno, strerror(errno));
    return rv;
  }
  return rv;
}




