/* USB support for the Cyberjack family of readers.
 *
 * Previous version were (C) 2004-2005 by Harald Welte <laforge@gnumonks.org>
 * This version is a rewrite (asynchronous USB is no longer needed).
 *
 * (C) 2007 Martin Preuss <martin@libchipcard.de>
 *
 * Distributed and licensed under the terms of GNU LGPL, Version 2.1
 */

/*
 * This implementation expects the reader to not send any interrupt URB
 * whatsoever (as is the case  with newer firmware whose configuration 2
 * does not have an interrupt pipe).
 *
 * This implementation otherwise only uses plain libusb calls so it should
 * work on any system for which libusb is available.
 */


#ifdef HAVE_CONFIG_H
# include <config.h>
#endif


#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <usb.h>

#include "ausb_l.h"


#define DEBUGP(ah, format, ...) {\
  char dbg_buffer[256]; \
  \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: " format  , __LINE__ , ##__VA_ARGS__); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, NULL, 0);\
}


#define DEBUGL(ah, text, pData, ulDataLen) {\
  char dbg_buffer[256]; \
  \
  snprintf(dbg_buffer, sizeof(dbg_buffer)-1,\
  __FILE__":%5d: %s", __LINE__ , text); \
  dbg_buffer[sizeof(dbg_buffer)-1]=0; \
  ausb_log(ah, dbg_buffer, pData, ulDataLen);\
}






static int ausb3_start_interrupt(ausb_dev_handle *ah, int ep) {
  int rv;

  DEBUGP(ah, "Halting interrupt pipe.");
  rv=usb_control_msg(ah->uh,
		     0x02, /* host to device */
		     0x03, /* set feature */
		     0x00, /* halt */
		     ep,   /* endpoint */
		     NULL, 0,
		     1200);
  if (rv<0) {
    DEBUGP(ah, "unable to halt interrupt pipe (%d=%s)\n",
	   errno, strerror(errno));
    return -1;
  }
  return 0;
}



static int ausb3_stop_interrupt(ausb_dev_handle *ah) {
  return 0;
}



static int ausb3_bulk_write(ausb_dev_handle *ah, int ep,
			    char *bytes, int length, int timeout){
  int rv;

  do {
    rv=usb_bulk_write(ah->uh, ep, bytes, length, timeout);
  } while (rv < 0 && errno == EINTR);
  return rv;
}



static int ausb3_bulk_read(ausb_dev_handle *ah, int ep,
			   char *bytes, int size, int timeout){
  int rv;

  for (;;) {
    do {
      rv=usb_bulk_read(ah->uh, ep, bytes, size, timeout);
    } while (rv < 0 && errno == EINTR);

    if (rv>=1) {
      if (bytes[0]==0x40 || /* RDR_TO_PC_KEYEVENT */
	  bytes[0]==0x50) { /* RDR_TO_PC_NOTIFYSLOTCHANGE */
	DEBUGL(ah, "Interrupt URB received", bytes, rv);
	if (ah->cb.handler) {
	  DEBUGP(ah, "Calling interrupt handler %p with %p",
		 ah->cb.handler, ah->cb.userdata);
	  ah->cb.handler((uint8_t*)bytes, rv, ah->cb.userdata);
	  DEBUGP(ah, "Calling interrupt handler: done");
	}
	else {
          DEBUGP(ah, "No interrupt handler");
	}
      }
      else
        break;
    }
    else
      break;
  }

  return rv;
}



/* not static since this function is needed in ausb.c */
int ausb3_extend(ausb_dev_handle *ah){
  DEBUGP(ah, "Extending AUSB handle as type 3");
  ah->bulkWriteFn=ausb3_bulk_write;
  ah->bulkReadFn=ausb3_bulk_read;
  ah->startInterruptFn=ausb3_start_interrupt;
  ah->stopInterruptFn=ausb3_stop_interrupt;

  return 0;
}


