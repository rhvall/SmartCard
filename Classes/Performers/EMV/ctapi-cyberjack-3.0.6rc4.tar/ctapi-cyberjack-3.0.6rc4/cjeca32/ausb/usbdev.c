
#ifdef HAVE_CONFIG_H
# include <config.h>
#endif


#include "usbdev_l.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <sys/stat.h>
#include <errno.h>

#ifdef USE_LIBSYSFS
# include <sysfs/libsysfs.h>
#endif


/* #define DEBUG_USBDEV_C */


#define RSCT_LIST_ADD(typ, sr, head) {\
  typ *curr;                \
                            \
  assert(sr);               \
                            \
  curr=*head;               \
  if (!curr) {              \
    *head=sr;               \
  }                         \
  else {                    \
    while(curr->next) {     \
      curr=curr->next;      \
    }                       \
    curr->next=sr;          \
  }\
  }


#define RSCT_LIST_DEL(typ, sr, head) {\
  typ *curr;                   \
                               \
  assert(sr);                  \
  curr=*head;                  \
  if (curr) {                  \
    if (curr==sr) {            \
      *head=curr->next;        \
    }                          \
    else {                     \
      while(curr->next!=sr) {  \
	curr=curr->next;       \
      }                        \
      if (curr)                \
	curr->next=sr->next;   \
    }                          \
  }                            \
  sr->next=0;\
  }



rsct_usbdev_t *rsct_usbdev_new() {
  rsct_usbdev_t *d;

  d=(rsct_usbdev_t*) malloc(sizeof(rsct_usbdev_t));
  if (d==NULL)
    return NULL;
  memset(d, 0, sizeof(rsct_usbdev_t));
  return d;
}



void rsct_usbdev_free(rsct_usbdev_t *d) {
  if (d) {
    free(d);
  }
}



void rsct_usbdev_list_add(rsct_usbdev_t **h, rsct_usbdev_t *d) {
  RSCT_LIST_ADD(rsct_usbdev_t, d, h);
}



void rsct_usbdev_list_free(rsct_usbdev_t *d) {
  while(d) {
    rsct_usbdev_t *dNext;

    dNext=d->next;
    rsct_usbdev_free(d);
    d=dNext;
  }
}





int rsct_usbdev_scan(rsct_usbdev_t **usbdev_list) {
#ifndef USE_LIBSYSFS
  fprintf(stderr, "RSCT: No support for LibSysFS\n");
  return -1;
#else
  struct sysfs_bus *bus = NULL;
  struct sysfs_device *curdev = NULL;
#ifndef HAVE_SYSFS2
  struct sysfs_device *temp_device = NULL;
#endif
  struct sysfs_device *parent = NULL;
  struct sysfs_attribute *cur = NULL;
  struct dlist *devlist = NULL;
  struct dlist *attributes = NULL;

  bus = sysfs_open_bus("usb");
  if (bus == NULL) {
    return -1;
  }

  devlist = sysfs_get_bus_devices(bus);
  if (devlist != NULL) {
    dlist_for_each_data(devlist, curdev,
			struct sysfs_device) {
      /* found something, well maybe */
      parent=sysfs_get_device_parent(curdev);
      if (parent) {
	int hasIds=0;
	int busPos=0;
	int vendorId=0;
	int productId=0;
	char serial[128];

	serial[0]=0;
	attributes=sysfs_get_device_attributes(parent);
	dlist_for_each_data(attributes, cur,
			    struct sysfs_attribute) {
	  if (strcmp(cur->name,"idVendor")==0) {
	    if (cur->value != NULL) {
	      vendorId = strtol(cur->value, NULL, 16);
	      hasIds|=0x01;
	    }
#ifdef DEBUG_USBDEV_C
	    else {
	      fprintf(stderr,"idVendor empty\n");
	    }
#endif
	  }
	  else if (strcmp(cur->name,"idProduct")==0) {
	    if (cur->value != NULL) {
	      productId = strtol(cur->value, NULL, 16);
	      hasIds|=0x02;
	    }
#ifdef DEBUG_USBDEV_C
	    else {
	      fprintf(stderr, "idProduct empty\n");
	    }
#endif
	  }
	  else if (strcmp(cur->name,"devnum")==0) {
	    if (cur->value != NULL) {
	      busPos=strtol(cur->value, NULL, 10);
	      hasIds|=0x04;
	    }
#ifdef DEBUG_USBDEV_C
	    else {
	      fprintf(stderr, "idProduct empty\n");
	    }
#endif
	  }
	  else if (strcmp(cur->name,"serial")==0) {
	    if (cur->value != NULL) {
	      strncpy(serial, cur->value, sizeof(serial)-1);
	      serial[sizeof(serial)-1]=0;
	      hasIds|=0x08;
	    }
#ifdef DEBUG_USBDEV_C
	    else {
	      fprintf(stderr, "serial number empty\n");
	    }
#endif
	  }
	} /* for attributes */
	if ((hasIds & 0x07)==0x07) {
	  char *s;
	  char *p;
	  int busId=0;

	  /* try to get bus id */
	  s=strdup(curdev->bus_id);
	  p=strchr(s, '-');
	  if (p) {
	    *p=0;
	    if (isdigit(*s))
	      busId=atoi(s);
	  }
	  free(s);

	  if (busId) {
	    char pbuff[256];
	    struct stat st;
	    int havePath=0;

	    snprintf(pbuff, sizeof(pbuff),
		     "/dev/bus/usb/%03d/%03d",
		     busId, busPos);
	    if (stat(pbuff, &st)==0) {
	      havePath=1;
	    }
	    else {
	      snprintf(pbuff, sizeof(pbuff),
		       "/proc/bus/usb/%03d/%03d",
		       busId, busPos);
	      if (stat(pbuff, &st)==0) {
		havePath=1;
	      }
	    }

	    if (havePath) {
	      rsct_usbdev_t *d;

	      /* create device */
	      d=rsct_usbdev_new();
	      strncpy(d->path, pbuff, sizeof(d->path)-1);
	      d->path[sizeof(d->path)-1]=0;

	      if (hasIds & 0x08) {
		int l;

		strncpy(d->serial, serial, sizeof(d->serial)-1);
		d->serial[sizeof(d->serial)-1]=0;
		l=strlen(d->serial);
		if (l && d->serial[l-1]=='\n')
		  d->serial[l-1]=0;
	      }
#ifdef DEBUG_USBDEV_C
	      else {
		fprintf(stderr,
			"Device %04x/%04x at %03d/%03d "
			"has no serial number\n",
			vendorId, productId,
			busId, busPos);
	      }
#endif
	      d->busId=busId;
	      d->busPos=busPos;
	      d->vendorId=vendorId;
	      d->productId=productId;
	      rsct_usbdev_list_add(usbdev_list, d);
	    }
#ifdef DEBUG_USBDEV_C
	    else {
	      fprintf(stderr, "No path for %04x/%04x at %03d/%03d.\n",
		      vendorId, productId, busId, busPos);
	    }
#endif
	  }
#ifdef DEBUG_USBDEV_C
	  else {
	    fprintf(stderr, "No bus id for %04x/%04x.\n",
		    vendorId, productId);
	  }
#endif
	}
      }
#ifdef DEBUG_USBDEV_C
      else {
	fprintf(stderr,"Error getting device parent for USB\n");
      }
#endif
    }
  }
  sysfs_close_bus(bus);
  return 0;
#endif
}



int rsct_get_serial_for_port(int port,
			     const char *fname,
			     char *sbuff,
			     int blen) {
  FILE *f;

  f=fopen(fname, "r");
  if (f==NULL)
    return -1;
  else {
    char lbuf[256];
    int idx=1;

    while(!feof(f)) {
      int llen;

      lbuf[0]=0;
      if (0==fgets(lbuf, sizeof(lbuf), f)) {
	if (ferror(f)) {
	  fprintf(stderr, "RSCT: fgets: %s\n", strerror(errno));
	  fclose(f);
	  return -1;
	}
	else
          break;
      }

      /* remove possibly trailing CR */
      llen=strlen(lbuf);
      if (llen && lbuf[llen-1]=='\n')
        lbuf[llen-1]=0;

      if (idx==port) {
	if (blen<(strlen(lbuf)+1)) {
	  fprintf(stderr, "RSCT: Buffer too small for serial number\n");
	  fclose(f);
	  return -1;
	}
	strcpy(sbuff, lbuf);
	fclose(f);
        /* success */
        return 0;
      }
      idx++;
    } /* while !feof */
    fclose(f);
  }

  /* not found */
  return 1;
}



int rsct_get_port_for_serial(const char *fname,
			     const char *serial) {
  FILE *f;

  f=fopen(fname, "r");
  if (f==NULL)
    /* no port */
    return 0;
  else {
    char lbuf[256];
    int idx=1;

    while(!feof(f)) {
      int llen;

      lbuf[0]=0;
      if (NULL==fgets(lbuf, sizeof(lbuf), f)) {
	if (ferror(f)) {
	  fprintf(stderr, "RSCT: fgets: %s\n", strerror(errno));
	  fclose(f);
	  return -1;
	}
	else
          break;
      }

      /* remove possibly trailing CR */
      llen=strlen(lbuf);
      if (llen && lbuf[llen-1]=='\n')
        lbuf[llen-1]=0;

      if (strcasecmp(serial, lbuf)==0) {
	fclose(f);
        /* success */
	return idx;
      }
      idx++;
    } /* while !feof */
    fclose(f);
  }

  /* not found */
  return 0;
}



int rsct_enum_serials(const char *fname) {
  int rv;
  rsct_usbdev_t *devs=NULL;
  rsct_usbdev_t *d;

  /* sample all devices */
  rv=rsct_usbdev_scan(&devs);
  if (rv)
    return rv;

  d=devs;
  while(d) {
    if (d->vendorId==0xc4b && d->serial[0]) {
      rv=rsct_get_port_for_serial(fname, d->serial);
      if (rv==0) {
	FILE *f;

	/* new device, serial number is unknown, add it */
	f=fopen(fname, "a+");
	if (f==NULL) {
	  fprintf(stderr, "RSCT: fopen(%s): %s\n",
                  fname, strerror(errno));
	  rsct_usbdev_list_free(devs);
	  return -1;
	}
	fprintf(f, "%s\n", d->serial);
	if (fclose(f)) {
	  fprintf(stderr, "RSCT: fclose(%s): %s\n",
		  fname, strerror(errno));
	  rsct_usbdev_list_free(devs);
	  return -1;
	}
      }
    }
    d=d->next;
  }

  rsct_usbdev_list_free(devs);
  return 0;
}




