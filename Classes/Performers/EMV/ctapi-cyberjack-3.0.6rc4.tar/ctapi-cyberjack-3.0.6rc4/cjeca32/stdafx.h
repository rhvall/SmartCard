// stdafx.h : Includedatei f�r Standardsystem-Includedateien
// oder h�ufig verwendete projektspezifische Includedateien,
// die nur in unregelm��igen Abst�nden ge�ndert werden.
//


#ifndef ECA_STDAFX_H
#define ECA_STDAFX_H



#ifdef HAVE_CONFIG_H
# include <config.h>
#endif



#ifdef _WINDOWS




// --------------------------------------------------------------------------
// Platform: Windows
  
// �ndern Sie folgende Definitionen f�r Plattformen, die �lter als die unten angegebenen sind.
// In MSDN finden Sie die neuesten Informationen �ber die entsprechenden Werte f�r die unterschiedlichen Plattformen.
# ifndef WINVER				// Lassen Sie die Verwendung spezifischer Features von Windows XP oder sp�ter zu.
#  define WINVER 0x0501		// �ndern Sie dies in den geeigneten Wert f�r andere Versionen von Windows.
# endif

# ifndef _WIN32_WINNT		// Lassen Sie die Verwendung spezifischer Features von Windows XP oder sp�ter zu.                   
#  define _WIN32_WINNT 0x0501	// �ndern Sie dies in den geeigneten Wert f�r andere Versionen von Windows.
# endif						

# ifndef _WIN32_WINDOWS		// Lassen Sie die Verwendung spezifischer Features von Windows 98 oder sp�ter zu.
#  define _WIN32_WINDOWS 0x0410 // �ndern Sie dies in den geeigneten Wert f�r Windows Me oder h�her.
# endif

# ifndef _WIN32_IE			// Lassen Sie die Verwendung spezifischer Features von IE 6.0 oder sp�ter zu.
#  define _WIN32_IE 0x0600	// �ndern Sie dies in den geeigneten Wert f�r andere Versionen von IE.
# endif

# define WIN32_LEAN_AND_MEAN		// Selten verwendete Teile der Windows-Header nicht einbinden.

# define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1
# define _INSERT_KEY_EVENTS


#ifdef UNDER_CE
	#define STRSAFE_NO_DEPRECATE
	struct _CONTEXT;
	struct CONTEXT;
	typedef struct _CONTEXT *PCONTEXT;
	#pragma comment(lib, "Coredll.lib")
	#include "excpt.h"
	#define _EXP_CTAPI

#endif


#elif defined (_LINUX) || defined(_MAC)
// --------------------------------------------------------------------------
// Platform: Linux / Mac OS X

// global headers special to Linux and/or Mac OS X
# include <inttypes.h>
# include <arpa/inet.h>
# include <stdlib.h>
# include <unistd.h>
# include <ctype.h>

# define RSCT_STDCALL

// definitions taken from pcsclite.h of project PC/SC lite
# define SCARD_S_SUCCESS			0x00000000
# define SCARD_E_CANCELLED		0x80100002
# define SCARD_E_CANT_DISPOSE		0x8010000E
# define SCARD_E_INSUFFICIENT_BUFFER	0x80100008
# define SCARD_E_INVALID_ATR		0x80100015
# define SCARD_E_INVALID_HANDLE		0x80100003
# define SCARD_E_INVALID_PARAMETER	0x80100004
# define SCARD_E_INVALID_TARGET		0x80100005
# define SCARD_E_INVALID_VALUE		0x80100011
# define SCARD_E_NO_MEMORY		0x80100006
# define SCARD_F_COMM_ERROR		0x80100013
# define SCARD_F_INTERNAL_ERROR		0x80100001
# define SCARD_F_UNKNOWN_ERROR		0x80100014
# define SCARD_F_WAITED_TOO_LONG		0x80100007
# define SCARD_E_UNKNOWN_READER		0x80100009
# define SCARD_E_TIMEOUT			0x8010000A
# define SCARD_E_SHARING_VIOLATION	0x8010000B
# define SCARD_E_NO_SMARTCARD		0x8010000C
# define SCARD_E_UNKNOWN_CARD		0x8010000D
# define SCARD_E_PROTO_MISMATCH		0x8010000F
# define SCARD_E_NOT_READY		0x80100010
# define SCARD_E_SYSTEM_CANCELLED	0x80100012
# define SCARD_E_NOT_TRANSACTED		0x80100016
# define SCARD_E_READER_UNAVAILABLE	0x80100017

# define SCARD_W_UNSUPPORTED_CARD	0x80100065
# define SCARD_W_UNRESPONSIVE_CARD	0x80100066
# define SCARD_W_UNPOWERED_CARD		0x80100067
# define SCARD_W_RESET_CARD		0x80100068
# define SCARD_W_REMOVED_CARD		0x80100069

# define SCARD_E_PCI_TOO_SMALL		0x80100019
# define SCARD_E_READER_UNSUPPORTED	0x8010001A
# define SCARD_E_DUPLICATE_READER	0x8010001B
# define SCARD_E_CARD_UNSUPPORTED	0x8010001C
# define SCARD_E_NO_SERVICE		0x8010001D
# define SCARD_E_SERVICE_STOPPED	0x8010001E

# define SCARD_E_UNSUPPORTED_FEATURE	0x8010001F

# define SCARD_SCOPE_USER		0x0000	/* Scope in user space */
# define SCARD_SCOPE_TERMINAL		0x0001	/* Scope in terminal */
# define SCARD_SCOPE_SYSTEM		0x0002	/* Scope in system */

# define SCARD_PROTOCOL_UNDEFINED     	0x00000000 /* protocol not set */
# define SCARD_PROTOCOL_T0		0x00000001 /* T=0 active protocol. */
# define SCARD_PROTOCOL_T1		0x00000002 /* T=1 active protocol. */
# define SCARD_PROTOCOL_RAW		0x00010000 /* Raw active protocol. */
# define SCARD_PROTOCOL_T15		0x00000008 /* T=15 protocol. */
# define SCARD_PROTOCOL_DEFAULT         0x80000000 /* use implicit pts */
# define SCARD_PROTOCOL_OPTIMAL         0x00000000


# define SCARD_PROTOCOL_ANY		(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1)	/* IFD determines prot. */

# define SCARD_SHARE_EXCLUSIVE		0x0001	/* Exclusive mode only */
# define SCARD_SHARE_SHARED		0x0002	/* Shared mode only */
# define SCARD_SHARE_DIRECT		0x0003	/* Raw mode only */

# define SCARD_LEAVE_CARD		0x0000	/* Do nothing on close */
# define SCARD_RESET_CARD		0x0001	/* Reset on close */
# define SCARD_UNPOWER_CARD		0x0002	/* Power down on close */
# define SCARD_EJECT_CARD		0x0003	/* Eject on close */

# define SCARD_UNKNOWN			0x0001	/* Unknown state */
# define SCARD_ABSENT			0x0002	/* Card is absent */
# define SCARD_PRESENT			0x0004	/* Card is present */
# define SCARD_SWALLOWED			0x0008	/* Card not powered */
# define SCARD_POWERED			0x0010	/* Card is powered */
# define SCARD_NEGOTIABLE		0x0020	/* Ready for PTS */
# define SCARD_SPECIFIC			0x0040	/* PTS has been set */

# define SCARD_STATE_UNAWARE		0x0000	/* App wants status */
# define SCARD_STATE_IGNORE		0x0001	/* Ignore this reader */
# define SCARD_STATE_CHANGED		0x0002	/* State has changed */
# define SCARD_STATE_UNKNOWN		0x0004	/* Reader unknown */
# define SCARD_STATE_UNAVAILABLE		0x0008	/* Status unavailable */
# define SCARD_STATE_EMPTY		0x0010	/* Card removed */
# define SCARD_STATE_PRESENT		0x0020	/* Card inserted */
# define SCARD_STATE_ATRMATCH		0x0040	/* ATR matches card */
# define SCARD_STATE_EXCLUSIVE		0x0080	/* Exclusive Mode */
# define SCARD_STATE_INUSE		0x0100	/* Shared Mode */
# define SCARD_STATE_MUTE		0x0200	/* Unresponsive card */
# define SCARD_STATE_UNPOWERED		0x0400	/* Unpowered card */

// some special definitions from windows
#define SCARD_AUTOALLOCATE ((uint32_t)-1)

#define SCARD_POWER_DOWN 0x0000
#define SCARD_COLD_RESET 0x0001
#define SCARD_WARM_RESET 0x0002

# define max(a, b) ((a>b)?a:b)

#define Sleep(ms) usleep(ms*1000)
#define strupr(s) {\
  char *p=s; \
  while(*p) {*p=toupper(*p); p++; }\
  }


# if defined (_LINUX)
// internal headers special to Linux
#  include "USBLinux.h"
#  include "SerialLinux.h"
# endif // _LINUX

# if defined (_MAC)
// internal headers special to Mac OS X
#  include <CoreServices/CoreServices.h>
#  include "pcscdefines.h"
#  include "USBMacOSX.h"
#  define _INSERT_KEY_EVENTS 1
# endif // _MAC


#endif // _LINUX || _MAC

// --------------------------------------------------------------------------
// common for all systems


#include <string.h>
#include "ntstatus.h"

#include "cjeca32.h"
#include "Debug.h"
#include "RSCTCriticalSection.h"
#include "BaseCommunication.h"
#ifdef _WINDOWS
	#ifdef UNDER_CE
		#include "USBCommunicationCe.h"
	#else
		#include "USBCommunication.h"
		#include "SerialCommunication.h"
	#endif
#endif
#include "BaseReader.h"
#include "CCIDReader.h"
#include "EC30Reader.h"
#include "ECAReader.h"
#include "Reader.h"







#endif

