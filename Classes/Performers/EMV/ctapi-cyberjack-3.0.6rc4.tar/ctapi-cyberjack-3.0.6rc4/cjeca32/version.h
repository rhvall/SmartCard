
#ifndef CJECA32_VERSION_H
#define CJECA32_VERSION_H

#define FVER_MAJOR      1
#define FVER_MINOR      3
#define FVER_PATCHLEVEL 5
#define FVER_BUILD      0

#define FVER_STRING "1, 3, 5, 0"


#define PVER_MAJOR      6
#define PVER_MINOR      4
#define PVER_PATCHLEVEL 2
#define PVER_BUILD      0

#define PVER_STRING "6, 4, 2, 0"


#endif

