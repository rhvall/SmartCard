/***************************************************************************
 $RCSfile$
                             -------------------
    cvs         : $Id: USBLinux.cpp 2007-04-19 10:27:17Z mpreuss $
    begin       : Wed Apr 18 2007
    copyright   : (C) 2007 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Lesser General Public            *
 *   License as published by the Free Software Foundation; either          *
 *   version 2.1 of the License, or (at your option) any later version.    *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *
 *   MA  02111-1307  USA                                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include "stdafx.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>

#include <string>

#include "USBLinux.h"
#include "ausb_l.h"


#define USB_TIMEOUT		10000000
#define USB_READ_TIMEOUT	USB_TIMEOUT
#define USB_WRITE_TIMEOUT	USB_TIMEOUT



static void logAusb(ausb_dev_handle *ah,
		    const char *text,
		    const void *pData, uint32_t ulDataLen) {

  rsct_debug_out("<USB>",
		 DEBUG_MASK_COMMUNICATION_IN,
		 (char*)text,
		 (char*)pData, ulDataLen);
}



extern "C" {
void usb_callback(const uint8_t *data,
		  uint32_t dlength,
		  void *userdata) {
  CUSBLinux *com;

  com=(CUSBLinux*) userdata;
  com->usbCallback(data, dlength);
}
}



char *CUSBLinux::createDeviceName(int num) {
  struct usb_device *dev;
  char buffer[256];

  /* get device */
  dev=ausb_get_dev_by_idx(num);
  if (dev==NULL) {
    Debug.Out("<no reader>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Device not found",0,0);
    return NULL;
  }

  snprintf(buffer, sizeof(buffer),
	   "usb:%04x/%04x:libusb:%s:%s",
	   dev->descriptor.idVendor,
	   dev->descriptor.idProduct,
	   dev->bus->dirname,
	   dev->filename);
  //fprintf(stderr, "Creating device name \"%s\"\n", buffer);

  return strdup(buffer);
}



char *CUSBLinux::createDeviceName(int busId, int devId) {
  struct usb_device *dev;
  char buffer[256];

  /* get device */
  dev=ausb_get_dev_by_bus_pos(busId, devId);
  if (dev==NULL) {
    Debug.Out("<no reader>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Device not found",0,0);
    return NULL;
  }

  snprintf(buffer, sizeof(buffer),
	   "usb:%04x/%04x:libusb:%s:%s",
	   dev->descriptor.idVendor,
	   dev->descriptor.idProduct,
	   dev->bus->dirname,
	   dev->filename);
  //fprintf(stderr, "Creating device name \"%s\"\n", buffer);

  return strdup(buffer);
}



CUSBLinux::CUSBLinux(char *cDeviceName,CReader *Owner)
:CBaseCommunication(cDeviceName, Owner)
,m_refcounter(1)
,m_devHandle(NULL)
,m_pid(0)
,m_bulkIn(0)
,m_bulkOut(0)
,m_intPipe(0)
{
  /* set log function */
  ausb_set_log_fn(logAusb);
}



CUSBLinux::~CUSBLinux(void) {
  m_refcounter=0;
  Close();
}



int CUSBLinux::Write(void *Message, uint32_t len) {
  int rv;

  rv=CBaseCommunication::Write(Message,len);
  if (rv==CJ_SUCCESS) {
    rv=ausb_bulk_write(m_devHandle, m_bulkOut,
		       (char*) Message, len,
		       USB_WRITE_TIMEOUT);
    if (rv<0) {
      Debug.Out(m_cDeviceName,
		DEBUG_MASK_COMMUNICATION_ERROR,
		"Error on write",0,0);
      Close();
      return CJ_ERR_DEVICE_LOST;
    }

    return CJ_SUCCESS;
  }
  else
    return rv;
}



int CUSBLinux::Read(void *Response, uint32_t *ResponseLen) {
  int rv;

  rv=ausb_bulk_read(m_devHandle, m_bulkIn,
		    (char*)Response, *ResponseLen,
		    USB_READ_TIMEOUT);
  if (rv<0) {
    Debug.Out(m_cDeviceName,
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Error on read",0,0);
    Close();
    return CJ_ERR_DEVICE_LOST;
  }

  *ResponseLen=rv;
  return CBaseCommunication::Read(Response, ResponseLen);
}



CBaseReader *CUSBLinux::BuildReaderObject() {
  struct usb_device *dev;

  dev=ausb_get_dev_by_name(m_cDeviceName);
  if (dev==NULL) {
    Debug.Out(m_cDeviceName,DEBUG_MASK_COMMUNICATION_ERROR,"Device not found",0,0);
    return NULL;
  }

  if (dev->descriptor.idVendor==AUSB_CYBERJACK_VENDOR_ID) {
    switch(dev->descriptor.idProduct) {
    case 0x400:
      m_Reader=new CECAReader(m_Owner, this);
      m_pid=dev->descriptor.idProduct;
      return m_Reader;

      /* add more readers here */

    default:
      return NULL;
    }
  }
  else {
    Debug.Out(m_cDeviceName,DEBUG_MASK_COMMUNICATION_ERROR,"Device is not a cyberjack",0,0);
    return NULL;
  }
}



void CUSBLinux::SetCommunicationString(cj_ReaderInfo *ReaderInfo) {
  ReaderInfo->PID=m_pid;
  memcpy(ReaderInfo->CommunicationString, "USB", 4);

  ReaderInfo->ContentsMask=
    RSCT_READER_MASK_PID |
    RSCT_READER_MASK_COM_TYPE;
}



bool CUSBLinux::IsConnected() {
  return (m_devHandle!=NULL);
}



int CUSBLinux::Open() {
  struct usb_device *dev;
  struct usb_config_descriptor *config;
  int nConfig=0;
  int usbMode=1;
  int rv;

  m_bulkIn=0;
  m_bulkOut=0;
  m_intPipe=0;

  /* get device */
  dev=ausb_get_dev_by_name(m_cDeviceName);
  if (dev==NULL) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Device not found",0,0);
    return 0;
  }

  /* get addresses of bulk endpoints */
  nConfig=0;
  if (dev->descriptor.idProduct==0x400 ||
      dev->descriptor.idProduct==0x401) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Using USB implementation 3", 0, 0);
    usbMode=3;
  }
  else {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Using USB implementation 1", 0, 0);
    usbMode=1;
  }

#if 0
#ifndef USE_SUSE_HACK
  /* apparently SuSE has very big problems with the following line.
   * All SuSE 10.x systems I tested make the driver abort at this point
   * and I can't say why. So for now I just disable this check here on
   * affected systems.
   */
  s=getenv("CJ_USB_MODE");
  if (s) {
    int u;

    u=atoi(s);
    if (u) {
      Debug.Out("<USB>",
		DEBUG_MASK_COMMUNICATION_ERROR,
		"Forced USB mode via environment variable CJ_USB_MODE", 0, 0);
      usbMode=u;
    }
  }
#endif
#endif

  config=&dev->config[nConfig];
  if (config->bNumInterfaces>0 &&
      config->interface &&
      config->interface->num_altsetting>0 &&
      config->interface->altsetting) {
    int i;
    struct usb_endpoint_descriptor *ep;

    ep=config->interface->altsetting->endpoint;
    for (i=0;
	 i<config->interface->altsetting->bNumEndpoints;
	 i++) {
      uint8_t addr;
      uint8_t att;

      addr=ep->bEndpointAddress;
      att=ep->bmAttributes;

      /* check for bulk write */
      if ((addr & USB_ENDPOINT_DIR_MASK)==USB_ENDPOINT_OUT &&
	  (att & USB_ENDPOINT_TYPE_MASK)==USB_ENDPOINT_TYPE_BULK)
	m_bulkOut=addr & (USB_ENDPOINT_ADDRESS_MASK | USB_ENDPOINT_DIR_MASK);

      /* check for bulk read */
      if ((addr & USB_ENDPOINT_DIR_MASK)==USB_ENDPOINT_IN &&
	  (att & USB_ENDPOINT_TYPE_MASK)==USB_ENDPOINT_TYPE_BULK)
	m_bulkIn=addr & (USB_ENDPOINT_ADDRESS_MASK | USB_ENDPOINT_DIR_MASK);

      /* check for interrupt pipe */
      if ((addr & USB_ENDPOINT_DIR_MASK)==USB_ENDPOINT_IN &&
	  (att & USB_ENDPOINT_TYPE_MASK)==USB_ENDPOINT_TYPE_INTERRUPT)
	m_intPipe=addr & (USB_ENDPOINT_ADDRESS_MASK | USB_ENDPOINT_DIR_MASK);

      if (m_bulkIn!=0 && m_bulkOut!=0 && m_intPipe!=0)
	break;
      ep++;
    }
    if (m_bulkIn==0) {
      Debug.Out("<USB>",
		DEBUG_MASK_COMMUNICATION_ERROR,
		"Bulk-in endpoint missing on device", 0, 0);
      return 0;
    }
    if (m_bulkOut==0) {
      Debug.Out("<USB>",
		DEBUG_MASK_COMMUNICATION_ERROR,
		"Bulk-out endpoint missing on device", 0, 0);
      return 0;
    }
    if (m_intPipe==0) {
      Debug.Out("<USB>",
		DEBUG_MASK_COMMUNICATION_ERROR,
		"No interrupt endpoint on device, ignoring", 0, 0);
    }
  }
  else {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Device has no endpoints", 0, 0);
    return 0;
  }

  /* ok, we have all, open the device */
  m_devHandle=ausb_open(dev, usbMode);
  if (m_devHandle==NULL) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to open device",0,0);
    return 0;
  }

#if 0
  /* set configuration, this syncs driver and device */
  rv=ausb_set_configuration(m_devHandle, 1);
  if (rv) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to set configuration",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;
    return 0;
  }
#endif

  /* This will synchronize the toggle bit */
  ausb_reset_pipe(m_devHandle, m_bulkOut);
  ausb_reset_pipe(m_devHandle, m_bulkIn);


  Debug.Out("<USB>",
	    DEBUG_MASK_COMMUNICATION_ERROR,
	    "Claim interface", 0, 0);
  rv=ausb_claim_interface(m_devHandle, 0);
  if (rv<0) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Still unable to claim interface",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;
    return 0;
  }

  //fprintf(stderr, "register callback handler\n");
  ausb_register_callback(m_devHandle, usb_callback, (void*)this);

#if 0
  if (ausb_clear_halt(m_devHandle, m_bulkOut)) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to clear halt state on BULKOUT",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;

    return 0;
  }
#endif

#if 0
  if (ausb_reset_endpoint(m_devHandle, m_bulkOut)) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to reset BULKOUT",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;

    return 0;
  }

  if (ausb_reset_endpoint(m_devHandle, m_bulkIn)) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to reset BULKIN",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;

    return 0;
  }

  if (ausb_reset_endpoint(m_devHandle, m_intPipe)) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to reset INTPIPE",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;

    return 0;
  }

#endif

  //fprintf(stderr, "start interrupt\n");
  if (ausb_start_interrupt(m_devHandle, m_intPipe)) {
    Debug.Out("<USB>",
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Unable to start receiving interrupts",0,0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;

    return 0;
  }

  //fprintf(stderr, "device open.\n");

  return 1;
}



void CUSBLinux::Close() {
  //fprintf(stderr, "Closing communication\n");
  if (m_devHandle==NULL) {
    Debug.Out(m_cDeviceName,
	      DEBUG_MASK_COMMUNICATION_ERROR,
	      "Device not open",0,0);
  }
  else {
    ausb_stop_interrupt(m_devHandle);

#if 0
    ausb_reset(m_devHandle);
#endif
    ausb_release_interface(m_devHandle, 0);
    ausb_close(m_devHandle);
    m_devHandle=NULL;
  }
}



int CUSBLinux::StartInterruptPipe() {
  return 0;
}



int CUSBLinux::HaltInterruptPipe() {
  return 0;
}



void CUSBLinux::usbCallback(const uint8_t *data,
			    uint32_t dlength) {
  Debug.Out(m_cDeviceName,
	    DEBUG_MASK_COMMUNICATION_INT,
	    "Interrupt received",
	    (uint8_t*)data,
	    dlength);

  if (m_Reader) {
    m_Reader->DoInterruptCallback((uint8_t*)data, dlength);
  }
  else {
    fprintf(stderr, "No reader.\n");
  }
}









