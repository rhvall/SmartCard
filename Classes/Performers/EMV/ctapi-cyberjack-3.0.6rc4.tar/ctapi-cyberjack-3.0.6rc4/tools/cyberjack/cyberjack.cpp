/***************************************************************************
 * project      : Cyberjack Diagnoses Tool
    begin       : Fri Jan 26 2007
    copyright   : (C) 2007 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *             This file is licensed under the GPL version 2.              *
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/


#include "checksuite.h"

#include <stdio.h>
#include <string.h>
#include <errno.h>



int main(int argc, char **argv) {
  CheckSuite *cs;
  std::string xmlString;
  std::string reportString;
  std::string hintString;
  bool b;
  FILE *f;

  cs=new CheckSuite();
  cs->addStandardModules();
  b=cs->performChecks(xmlString, reportString, hintString);

  f=fopen("cyberjack.xml", "w+");
  if (f) {
    fprintf(f, "%s", xmlString.c_str());
    fclose(f);
  }
  else {
    fprintf(stderr, "fopen(\"cyberjack.xml\"): %s\n", strerror(errno));
  }

  f=fopen("cyberjack-report.log", "w+");
  if (f) {
    fprintf(f, "%s", reportString.c_str());
    fclose(f);
  }
  else {
    fprintf(stderr, "fopen(\"cyberjack-report.log\"): %s\n", strerror(errno));
  }

  f=fopen("cyberjack-hints.log", "w+");
  if (f) {
    fprintf(f, "%s", hintString.c_str());
    fclose(f);
  }
  else {
    fprintf(stderr, "fopen(\"cyberjack-hints.log\"): %s\n", strerror(errno));
  }

  fprintf(stderr,
	  "\n"
	  "Es wurden 3 Dateien im aktuellen Verzeichnis angelegt:\n"
	  "- cyberjack-report.log: Enthaelt die Ergebnisse der Tests\n"
	  "- cyberjack-hints.log : Enthaelt moeglicherweise Hinweise\n"
	  "                        zu gefundenen Problemen und deren\n"
	  "                        Behebung.\n"
	  "- cyberjack.xml       : Enthaelt die Testergebnisse in fuer\n"
	  "                        den Support aufbereiteter Form.\n"
	  "Bitte senden Sie bei Problemen die Datei \"cyberjack.xml\"\n"
	  "an den Linux-Support von Reiner SCT.\n"
	  "\n");

  return 0;
}


