/***************************************************************************
 * project      : Cyberjack Diagnoses Tool
    begin       : Fri Jan 26 2007
    copyright   : (C) 2007 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *             This file is licensed under the GPL version 2.              *
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/


#include "cm_reader.h"
#include "checksuite.h"

#include <errno.h>
#include <string.h>

#include <usb.h>
#include <inttypes.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>



#define CYBERJACK_VENDOR_ID 0xc4b



static bool _checkReader(CheckSuite *suite,
			 struct usb_device *dev,
			 const char *devName,
			 std::string &xmlString,
			 std::string &reportString,
			 std::string &hintString) {
  char buffer[256];
  std::string devPath;
  std::string usbDevPath;
  int8_t rv;
  int fd;
  uint8_t apdu[]={0x20, 0x13, 0x00, 0x46, 0x00};
  uint8_t responseBuffer[300];
  uint16_t lr;
  uint8_t sad, dad;

  snprintf(buffer, sizeof(buffer),
	   "%s/%s",
	   dev->bus->dirname,
	   dev->filename);
  buffer[sizeof(buffer)-1]=0;
  devPath=buffer;

  /* get device path (either in /dev/bus/usb or in /proc/bus/usb) */
  usbDevPath="/dev/bus/usb/"+devPath;
  fd=open(usbDevPath.c_str(), O_RDWR);
  if (fd==-1 && errno!=EPERM) {
    usbDevPath="/proc/bus/usb/"+devPath;
    fd=open(usbDevPath.c_str(), O_RDWR);
  }

  if (fd==-1) {
    if (errno==EPERM) {
      reportString+=
	"*FEHLER* (Benutzer hat keine Berechtigung fuer das Geraet)\n";
      xmlString+=
	"    <result type=\"error\" function=\"access\">\n"
	"      Benutzer hat keine Berechtigung fuer das Geraet.\n"
	"    </result>\n";
      hintString+=
	"Sie haben keine ausreichende Berechtigung um auf den Leser "
	"zuzugreifen.\n"
	"Abhilfe: Bitte installieren Sie das fuer Ihr System passende "
	"Paket. Reiner SCT bietet fuer die gaengigen Distributionen "
        "entsprechende Pakete an.\n"
	"Sie muessen dann den Benutzer, der auf den Leser zugreifen "
	"koennen soll, in die Gruppe \"cyberjack\" einfuegen.\n"
	"Dies koennen Sie unter SuSE mit yast (Modul "
	"\"Benutzer und Gruppen\") und auf anderen Systemen mit den "
	"entsprechenden Systemverwaltungstools (z.B. KUser) vornehmen.\n"
	"Nach einem Neustart Ihres Systems sollten Sie auf den Leser "
	"zugreifen koennen.\n\n";
    }
    else {
      const char *s;

      s=strerror(errno);
      reportString+="*FEHLER* (";
      reportString+=s;
      reportString+=")\n";

      xmlString+="    <result type=\"error\" function=\"access\">";
      xmlString+=s;
      xmlString+="    </result>\n";
    }

    return false;
  }
  else {
    close(fd);
    reportString+="Benutzer hat alle noetigen Rechte fuer den Leser an ";
    reportString+=devPath;
    reportString+=".\n";
  }


  /* try to init CTAPI */
  rv=suite->ctInitName(1, devName);
  if (rv!=0) {
    char numbuf[32];

    snprintf(numbuf, sizeof(numbuf)-1, "%d (%02x)", rv, rv);
    reportString+="*FEHLER* (rsct_init_name(1, ";
    reportString+=devName;
    reportString+="): ";
    reportString+=numbuf;
    reportString+="\n";

    xmlString+="      <result type=\"error\" function=\"rsct_init_name\">\n";
    xmlString+="        rsct_init_name(1, ";
    xmlString+=devName;
    xmlString+=")= ";
    xmlString+=numbuf;
    xmlString+="\n";
    xmlString+="      </result>\n";

    return false;
  }

  /* get information about firmware */
  lr=sizeof(responseBuffer);
  sad=2;
  dad=1;
  rv=suite->ctData(1, &dad, &sad, 5, apdu, &lr, responseBuffer);
  if (rv!=0) {
    char numbuf[32];

    snprintf(numbuf, sizeof(numbuf)-1, "%d", rv);
    reportString+="*FEHLER* (CT_data(1, GETINFO) [";
    reportString+=devName;
    reportString+="]: ";
    reportString+=numbuf;
    reportString+="\n";

    xmlString+="      <result type=\"error\" function=\"CT_data\">\n";
    xmlString+="        CT_data(1, GETINFO) ( ";
    xmlString+=devName;
    xmlString+=")= ";
    xmlString+=numbuf;
    xmlString+="\n";
    xmlString+="      </result>\n";

    return false;
  }
  else {
    int i;
    std::string fwString;

    for (i=0; i<responseBuffer[1]; i++) {
      if (isprint(responseBuffer[2+i]))
	fwString+=responseBuffer[2+i];
      else
	fwString+='.';
    }

    reportString+="Firmware info for [";
    reportString+=devName;
    reportString+="]: [";
    reportString+=fwString;
    reportString+="]\n";

    xmlString+="      <result type=\"success\">\n";
    xmlString+="        <fwinfo reader=\"";
    xmlString+=devName;
    xmlString+="\">\n";

    xmlString+="          \"";
    xmlString+=fwString;
    xmlString+="\"\n";

    xmlString+="        </fwinfo>\n";
    xmlString+="      </result>\n";
  }

  rv=suite->ctClose(1);
  if (rv!=0) {
    char numbuf[32];

    snprintf(numbuf, sizeof(numbuf)-1, "%d", rv);
    reportString+="*FEHLER* (CT_close(1) [";
    reportString+=devName;
    reportString+="]: ";
    reportString+=numbuf;
    reportString+="\n";

    xmlString+="      <result type=\"error\" function=\"CT_close\">\n";
    xmlString+="        CT_close(1) ( ";
    xmlString+=devName;
    xmlString+=")= ";
    xmlString+=numbuf;
    xmlString+="\n";
    xmlString+="      </result>\n";

    return false;
  }

  xmlString+="      <result type=\"success\">\n";
  xmlString+="        Leser an (";
  xmlString+=devName;
  xmlString+=") ist verfuegbar.\n";
  xmlString+="      </result>\n";

  return true;
}



bool CM_Reader::check(std::string &xmlString,
		      std::string &reportString,
		      std::string &hintString) {
  struct usb_bus *busses, *bus;
  struct usb_device *dev;
  int readersFound=0;
  int readersOk=0;

  usb_init();
  usb_find_busses();
  usb_find_devices();

  busses=usb_get_busses();

  xmlString+="<check type=\"reader\">\n";

  for (bus=busses; bus; bus=bus->next) {
    for (dev=bus->devices; dev; dev=dev->next) {
      if (dev->descriptor.idVendor==CYBERJACK_VENDOR_ID) {
	char buffer[300];
	const char *devType;

        readersFound++;
	switch(dev->descriptor.idProduct) {
	case 0x100: devType="Cyberjack Pinpad/Ecom"; break;
	case 0x300: devType="Cyberjack Pinpad (a)"; break;
	case 0x400: devType="Cyberjack Ecom (a)"; break;
	case 0x401: devType="Cyberjack Ecom (mit Update)"; break;
	default:    devType="(unbekannter Typ)";
	}

	reportString+="Leser gefunden an ";
	snprintf(buffer, sizeof(buffer),
		 "%s/%s: %s (%04x:%04x)\n",
		 dev->bus->dirname,
		 dev->filename,
                 devType,
		 dev->descriptor.idVendor,
		 dev->descriptor.idProduct);
	buffer[sizeof(buffer)-1]=0;
	reportString+=buffer;

	xmlString+="  <reader>\n";
	snprintf(buffer, sizeof(buffer),
		 "    <idvendor>%04x</idvendor>\n"
		 "    <idproduct>%04x</idproduct>\n"
		 "    <busdir>%s</busdir>\n"
		 "    <devname>%s</devname>\n",
		 dev->descriptor.idVendor,
		 dev->descriptor.idProduct,
		 dev->bus->dirname,
		 dev->filename);
        buffer[sizeof(buffer)-1]=0;
	xmlString+=buffer;

	/* create device name */
	snprintf(buffer, sizeof(buffer),
		 "usb:%04x/%04x:libusb:%s:%s",
		 dev->descriptor.idVendor,
		 dev->descriptor.idProduct,
		 dev->bus->dirname,
		 dev->filename);
	buffer[sizeof(buffer)-1]=0;

        /* check this reader */
	xmlString+="    <test>\n";
	if (_checkReader(_suite, dev, buffer,
			 xmlString, reportString, hintString))
	  readersOk++;
	xmlString+="    </test>\n";
	xmlString+="  </reader>\n";
      }
    }
  }

  if (readersFound==0) {
    xmlString+="  <result type=\"error\">No readers found</result>\n";
    reportString+=
      "*FEHLER* (kein USB-Leser von Reiner SCT gefunden).\n";
    hintString+=
      "Auf Ihrem Rechner wurde kein USB-Leser von Reiner SCT gefunden.\n"
      "Bitte stellen Sie sicher, dass Ihr Leser angeschlossen ist.\n"
      "Unter Linux werden derzeit ausschliesslich die USB-Leser "
      "unterstuetzt, andere Leser jedoch nicht.\n";
    if (getuid()!=0)
      hintString+=
	"Bitte beachten Sie, dass diese Meldung auch auftreten kann, wenn "
	"Sie nicht Mitglied der Gruppe \"cyberjack\" sind. In diesem Fall "
	"haben Sie nicht die noetigen Rechte, um den Leser anzuzeigen.\n";
  }
  else if (readersOk!=readersFound) {
    hintString+=
      "Auf einige gefundene Leser konnte nicht zugegriffen werden.\n";
    xmlString+=
      "  <result type=\"error\">Some readers are not accessible</result>\n";
    reportString+=
      "*FEHLER* (nicht alle gefundenen Leser waren ansprechbar).\n";
    if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_PCSCD) {
      hintString+=
	"Moeglicherweise wird der Leser vom PC/SC Dienst verwendet.\n";
    }
    else if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_LCC1) {
      hintString+=
	"Moeglicherweise wird der Leser von Libchipcard1 verwendet.\n";
    }
    else if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_LCC2) {
      hintString+=
	"Moeglicherweise wird der Leser gerade von Libchipcard2 verwendet.\n";
    }
    else if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_LCC3) {
      hintString+=
	"Moeglicherweise wird der Leser gerade von Libchipcard3 verwendet.\n";
    }
    else if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_LCC4) {
      hintString+=
	"Moeglicherweise wird der Leser gerade von Libchipcard4 verwendet.\n";
    }
    else if (_suite->getFlags() & CHECKSUITE_FLAGS_HAVE_OPENCT) {
      hintString+=
	"Moeglicherweise wird der Leser vom OpenCT Dienst verwendet.\n";
    }
    else {
      hintString+=
	"Moeglicherweise wird der Leser gerade von einem anderen Programm "
	"verwendet.\n";
    }
  }
  else {
    xmlString+="  <result type=\"success\"></result>\n";
    reportString+="Alle gefundenen Leser sind ansprechbar.\n";
  }

  hintString+="\n";
  xmlString+="</check>\n";

  return (readersFound && readersFound==readersOk)?true:false;
}




