
#ifndef RSCT_CJECA32_H
#define RSCT_CJECA32_H

// Folgender ifdef-Block ist die Standardmethode zum Erstellen von Makros, die das Exportieren 
// aus einer DLL vereinfachen. Alle Dateien in dieser DLL werden mit dem CJECA32_EXPORTS-Symbol
// kompiliert, das in der Befehlszeile definiert wurde. Das Symbol darf nicht f�r ein Projekt definiert werden,
// das diese DLL verwendet. Alle anderen Projekte, deren Quelldateien diese Datei beinhalten, erkennen 
// CJECA32_API-Funktionen als aus einer DLL importiert, w�hrend die DLL
// mit diesem Makro definierte Symbole als exportiert ansieht.
#ifdef _WINDOWS
# ifdef CJECA32_EXPORTS
#  define CJECA32_API __declspec(dllexport)
# else
#  define CJECA32_API __declspec(dllimport)
# endif
# define CJECA32_PRIVATE_API
# define CJECA32_PRIVATE_CLASS
#
#
#elif defined(_LINUX)
# ifdef BUILDING_CYBERJACK
#  ifdef GCC_WITH_VISIBILITY_ATTRIBUTE
#   define CJECA32_API __attribute__((visibility("default")))
#   define CJECA32_PRIVATE_API __attribute__((visibility("hidden")))
#   define CJECA32_PRIVATE_CLASS __attribute__((visibility("hidden")))
#  else
#   define CJECA32_API
#   define CJECA32_PRIVATE_API
#   define CJECA32_PRIVATE_CLASS
#  endif
# else
#  define CJECA32_API
#  define CJECA32_PRIVATE_API
#  define CJECA32_PRIVATE_CLASS
# endif
#
# ifdef GCC_WITH_VISIBILITY_ATTRIBUTE
#  define CJECA32_EXPORT __attribute__((visibility("default")))
# else
#  define CJECA32_EXPORT
# endif
#
#
#elif defined(_MAC)
#  define CTAPI_RETURN CJECA32_API int8_t
#  if __GNUC__ >= 4
#  define CJECA32_API __attribute__((visibility("default")))
#  define CJECA32_PRIVATE_API __attribute__((visibility("hidden")))
#  define CJECA32_PRIVATE_CLASS __attribute__((visibility("hidden")))
#  else
#  define CJECA32_API 
#  define CJECA32_PRIVATE_API 
#  define CJECA32_PRIVATE_CLASS 
#endif
#endif


#ifdef _WINDOWS
// --------------------------------------------------------------------------
// Platform: Windows

# define RSCT_STDCALL _stdcall
# define strdup(m) _strdup(m)

// Windows-Headerdateien:
# include <windows.h>
# include <tchar.h>
# include <winsock2.h>
# include <winscard.h>

#define uint32_t ULONG
#define uint16_t USHORT
#define uint8_t BYTE

#define int32_t LONG
#define int16_t SHORT
#define int8_t char


/*typedef unsigned __int32 uint32_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int8 uint8_t;

typedef __int32 int32_t;
typedef __int16 int16_t;
typedef __int8 int8_t;*/


#elif defined (_LINUX)
// --------------------------------------------------------------------------
// Platform: Linux

// global headers special to Linux
# include <inttypes.h>
# include <arpa/inet.h>
# include <stdlib.h>
# include <unistd.h>
# include <ctype.h>

# define RSCT_STDCALL

// definitions taken from pcsclite.h of project PC/SC lite
# define SCARD_S_SUCCESS			0x00000000
# define SCARD_E_CANCELLED		0x80100002
# define SCARD_E_CANT_DISPOSE		0x8010000E
# define SCARD_E_INSUFFICIENT_BUFFER	0x80100008
# define SCARD_E_INVALID_ATR		0x80100015
# define SCARD_E_INVALID_HANDLE		0x80100003
# define SCARD_E_INVALID_PARAMETER	0x80100004
# define SCARD_E_INVALID_TARGET		0x80100005
# define SCARD_E_INVALID_VALUE		0x80100011
# define SCARD_E_NO_MEMORY		0x80100006
# define SCARD_F_COMM_ERROR		0x80100013
# define SCARD_F_INTERNAL_ERROR		0x80100001
# define SCARD_F_UNKNOWN_ERROR		0x80100014
# define SCARD_F_WAITED_TOO_LONG		0x80100007
# define SCARD_E_UNKNOWN_READER		0x80100009
# define SCARD_E_TIMEOUT			0x8010000A
# define SCARD_E_SHARING_VIOLATION	0x8010000B
# define SCARD_E_NO_SMARTCARD		0x8010000C
# define SCARD_E_UNKNOWN_CARD		0x8010000D
# define SCARD_E_PROTO_MISMATCH		0x8010000F
# define SCARD_E_NOT_READY		0x80100010
# define SCARD_E_SYSTEM_CANCELLED	0x80100012
# define SCARD_E_NOT_TRANSACTED		0x80100016
# define SCARD_E_READER_UNAVAILABLE	0x80100017

# define SCARD_W_UNSUPPORTED_CARD	0x80100065
# define SCARD_W_UNRESPONSIVE_CARD	0x80100066
# define SCARD_W_UNPOWERED_CARD		0x80100067
# define SCARD_W_RESET_CARD		0x80100068
# define SCARD_W_REMOVED_CARD		0x80100069

# define SCARD_E_PCI_TOO_SMALL		0x80100019
# define SCARD_E_READER_UNSUPPORTED	0x8010001A
# define SCARD_E_DUPLICATE_READER	0x8010001B
# define SCARD_E_CARD_UNSUPPORTED	0x8010001C
# define SCARD_E_NO_SERVICE		0x8010001D
# define SCARD_E_SERVICE_STOPPED	0x8010001E

# define SCARD_E_UNSUPPORTED_FEATURE	0x8010001F

# define SCARD_SCOPE_USER		0x0000	/* Scope in user space */
# define SCARD_SCOPE_TERMINAL		0x0001	/* Scope in terminal */
# define SCARD_SCOPE_SYSTEM		0x0002	/* Scope in system */

# define SCARD_PROTOCOL_UNDEFINED     	0x00000000 /* protocol not set */
# define SCARD_PROTOCOL_T0		0x00000001 /* T=0 active protocol. */
# define SCARD_PROTOCOL_T1		0x00000002 /* T=1 active protocol. */
# define SCARD_PROTOCOL_RAW		0x00010000 /* Raw active protocol. */
# define SCARD_PROTOCOL_T15		0x00000008 /* T=15 protocol. */
# define SCARD_PROTOCOL_DEFAULT         0x80000000 /* use implicit pts */
# define SCARD_PROTOCOL_OPTIMAL         0x00000000


# define SCARD_PROTOCOL_ANY		(SCARD_PROTOCOL_T0|SCARD_PROTOCOL_T1)	/* IFD determines prot. */

# define SCARD_SHARE_EXCLUSIVE		0x0001	/* Exclusive mode only */
# define SCARD_SHARE_SHARED		0x0002	/* Shared mode only */
# define SCARD_SHARE_DIRECT		0x0003	/* Raw mode only */

# define SCARD_LEAVE_CARD		0x0000	/* Do nothing on close */
# define SCARD_RESET_CARD		0x0001	/* Reset on close */
# define SCARD_UNPOWER_CARD		0x0002	/* Power down on close */
# define SCARD_EJECT_CARD		0x0003	/* Eject on close */

# define SCARD_UNKNOWN			0x0001	/* Unknown state */
# define SCARD_ABSENT			0x0002	/* Card is absent */
# define SCARD_PRESENT			0x0004	/* Card is present */
# define SCARD_SWALLOWED			0x0008	/* Card not powered */
# define SCARD_POWERED			0x0010	/* Card is powered */
# define SCARD_NEGOTIABLE		0x0020	/* Ready for PTS */
# define SCARD_SPECIFIC			0x0040	/* PTS has been set */

# define SCARD_STATE_UNAWARE		0x0000	/* App wants status */
# define SCARD_STATE_IGNORE		0x0001	/* Ignore this reader */
# define SCARD_STATE_CHANGED		0x0002	/* State has changed */
# define SCARD_STATE_UNKNOWN		0x0004	/* Reader unknown */
# define SCARD_STATE_UNAVAILABLE		0x0008	/* Status unavailable */
# define SCARD_STATE_EMPTY		0x0010	/* Card removed */
# define SCARD_STATE_PRESENT		0x0020	/* Card inserted */
# define SCARD_STATE_ATRMATCH		0x0040	/* ATR matches card */
# define SCARD_STATE_EXCLUSIVE		0x0080	/* Exclusive Mode */
# define SCARD_STATE_INUSE		0x0100	/* Shared Mode */
# define SCARD_STATE_MUTE		0x0200	/* Unresponsive card */
# define SCARD_STATE_UNPOWERED		0x0400	/* Unpowered card */


// some special definitions from windows
#define SCARD_AUTOALLOCATE ((uint32_t)-1)

#define SCARD_POWER_DOWN 0x0000
#define SCARD_COLD_RESET 0x0001
#define SCARD_WARM_RESET 0x0002

# define max(a, b) ((a>b)?a:b)

#define Sleep(ms) usleep(ms*1000)
#define strupr(s) {\
  char *p=s; \
  while(*p) {*p=toupper(*p); p++; }\
  }



#elif defined (_MAC)
// --------------------------------------------------------------------------
// Platform: MAC OSX
# define RSCT_STDCALL
#endif



#if defined(_LINUX) || defined(_MAC)

#define SCARD_CTL_CODE(code) (0x42000000 + (code))

typedef struct _SCARD_IO_REQUEST {
  unsigned long dwProtocol;
  unsigned long cbPciLength;
} SCARD_IO_REQUEST, *PSCARD_IO_REQUEST, *LPSCARD_IO_REQUEST;

typedef const SCARD_IO_REQUEST *LPCSCARD_IO_REQUEST;

#endif




#define CJ_SUCCESS                  0
#define CJ_ERR_OPENING_DEVICE      -1
#define CJ_ERR_WRITE_DEVICE        -2
#define CJ_ERR_DEVICE_LOST         -3
#define CJ_ERR_WRONG_ANSWER        -4
#define CJ_ERR_SEQ                 -5
#define CJ_ERR_WRONG_LENGTH        -6
#define CJ_ERR_NO_ICC              -7
#define CJ_ERR_OPEN_ICC            -8
#define CJ_ERR_PARITY              -9
#define CJ_ERR_TIMEOUT            -10
#define CJ_ERR_LEN                -11
#define CJ_ERR_RBUFFER_TO_SMALL   -12
#define CJ_ERR_PROT               -13
#define CJ_ERR_NO_ACTIVE_ICC      -14
#define CJ_ERR_SIGN               -15
#define CJ_ERR_WRONG_SIZE         -16
#define CJ_ERR_PIN_TIMEOUT        -17
#define CJ_ERR_PIN_CANCELED       -18
#define CJ_ERR_PIN_DIFFERENT      -19
#define CJ_ERR_FIRMWARE_OLD       -20
#define CJ_NOT_UPDATABLE          -21
#define CJ_ERR_NO_SIGN            -22
#define CJ_ERR_WRONG_PARAMETER    -23
#define CJ_ERR_INTERNAL_BUFFER_OVERFLOW -24
#define CJ_ERR_CHECK_RESULT		 -25
#define CJ_ERR_DATA_CORRUPT       -26

#define RSCT_MODULE_MASK_STATUS					0x00000001
#define RSCT_MODULE_MASK_ID						0x00000002
#define RSCT_MODULE_MASK_VARIANT					0x00000004
#define RSCT_MODULE_MASK_BASE_ADDR				0x00000008
#define RSCT_MODULE_MASK_CODE_SIZE			   0x00000010
#define RSCT_MODULE_MASK_VERSION			      0x00000020
#define RSCT_MODULE_MASK_REVISION		      0x00000040
#define RSCT_MODULE_MASK_REQUIRED_VERSION		0x00000080
#define RSCT_MODULE_MASK_REQUIRED_REVISION	0x00000100
#define RSCT_MODULE_MASK_HEAP_SIZE				0x00000200
#define RSCT_MODULE_MASK_DESCRIPTION			0x00000400
#define RSCT_MODULE_MASK_DATE						0x00000800


typedef struct _cj_ModuleInfo
{
	uint32_t SizeOfStruct;
	uint32_t ContentsMask;
   uint32_t Status;
   uint32_t ID;
   uint32_t Variant;
   uint32_t BaseAddr;
   uint32_t CodeSize;
   uint32_t Version;
   uint32_t Revision;
   uint32_t RequieredKernelVersion;
   uint32_t RequieredKernelRevision;
   uint32_t HeapSize;
   int8_t Description[17];
   int8_t Date[12];
   int8_t Time[6];
}cj_ModuleInfo;

#define RSCT_READER_MASK_PID						0x00000001
#define RSCT_READER_MASK_HARDWARE				0x00000002
#define RSCT_READER_MASK_VERSION					0x00000004
#define RSCT_READER_MASK_HARDWARE_VERSION		0x00000008
#define RSCT_READER_MASK_FLASH_SIZE				0x00000010
#define RSCT_READER_MASK_HEAP_SIZE				0x00000020
#define RSCT_READER_MASK_SERIALNUMBER			0x00000040
#define RSCT_READER_MASK_VENDOR_STRING			0x00000080
#define RSCT_READER_MASK_PRODUCT_STRING		0x00000100
#define RSCT_READER_MASK_PRODUCTION_DATE		0x00000200
#define RSCT_READER_MASK_TEST_DATE				0x00000400
#define RSCT_READER_MASK_COMMISSIONING_DATE	0x00000800
#define RSCT_READER_MASK_COM_TYPE	         0x00001000
#define RSCT_READER_MASK_PORT_ID	            0x00002000
#define RSCT_READER_MASK_IFD_BRIDGE          0x00004000
#define RSCT_READER_MASK_HW_STRING           0x00008000

#define RSCT_READER_HARDWARE_MASK_ICC1			0x00000001
#define RSCT_READER_HARDWARE_MASK_ICC2			0x00000002
#define RSCT_READER_HARDWARE_MASK_ICC3			0x00000004
#define RSCT_READER_HARDWARE_MASK_ICC4			0x00000008
#define RSCT_READER_HARDWARE_MASK_ICC5			0x00000010
#define RSCT_READER_HARDWARE_MASK_ICC6			0x00000020
#define RSCT_READER_HARDWARE_MASK_ICC7			0x00000040
#define RSCT_READER_HARDWARE_MASK_ICC8			0x00000080
#define RSCT_READER_HARDWARE_MASK_KEYPAD		0x00000100
#define RSCT_READER_HARDWARE_MASK_DISPLAY		0x00000200
#define RSCT_READER_HARDWARE_MASK_BIOMETRIC	0x00000400
#define RSCT_READER_HARDWARE_MASK_UPDATEABLE 0x00010000
#define RSCT_READER_HARDWARE_MASK_MODULES		0x00020000

typedef struct _tKeyInfo
{
	uint8_t KNr;
	uint8_t Version;
}tKeyInfo;

typedef struct _ReaderInfo
{
	uint32_t SizeOfStruct;
	uint32_t ContentsMask;
	uint32_t PID;
	uint32_t HardwareMask;
	uint32_t Version;
	uint32_t HardwareVersion;
	uint32_t FlashSize;
	uint32_t HeapSize;
	tKeyInfo Keys[2];
	int8_t SeriaNumber[11];
	int8_t VendorString[128];
	int8_t ProductString[128];
	int8_t ProductionDate[11];
	int8_t ProductionTime[6];
	int8_t TestDate[11];
	int8_t TestTime[6];
	int8_t CommissioningDate[11];
	int8_t CommissioningTime[6];
   int8_t CommunicationString[4];
	uint32_t PortID;
	int8_t IFDNameOfIfdBridgeDevice[256];
	int8_t HardwareString[128];
}cj_ReaderInfo;

typedef void* ctxPtr;
typedef void (RSCT_STDCALL *fctKeyIntCallback)(ctxPtr Context, uint8_t Key);
typedef void (RSCT_STDCALL *fctChangeIntCallback)(ctxPtr Context, uint8_t State);


typedef enum _EContrast{ContrastVeryLow,ContrastLow,ContrastMedium,ContrastHigh,ContrastVeryHigh}EContrast;

typedef int CJ_RESULT;
typedef uint32_t RSCT_IFD_RESULT;

typedef enum _EApduNorm{NORM_PCSC,NORM_ISO,NORM_EMV}EApduNorm;

#ifndef CJPCSC_VEN_IOCTRL_ESCAPE
#define CJPCSC_VEN_IOCTRL_ESCAPE	      SCARD_CTL_CODE(3103)
#endif


#ifndef _MAC

extern CJECA32_API int ncjeca32;

CJECA32_API int fncjeca32(void);

#ifdef __cplusplus
// Diese Klasse wird aus cjeca32.dll exportiert.
class CJECA32_API Ccjeca32 {
public:
	Ccjeca32(void);
	// TODO: Hier die Methoden hinzuf�gen.
};
#endif

#endif // !_MAC


#ifdef CJECA32_EXPORTS
#ifdef _EXP_CTAPI

#define CTAPI_RETURN CJECA32_API char _stdcall


#ifdef __cplusplus

extern "C"
{
#endif
   CTAPI_RETURN CT_init(WORD,WORD);
   CTAPI_RETURN CT_data(WORD,uint8_t *dad,uint8_t *sad, WORD cmd_len, const uint8_t *cmd, WORD *response_len, uint8_t *response);
   CTAPI_RETURN CT_close(WORD);
#ifdef __cplusplus
}
#endif
#endif
#endif

#endif

