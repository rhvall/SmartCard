#ifndef memory_placements_H
#define memory_placements_H

#define FLASH_SIZE 0x00040000

typedef struct
{
  unsigned short KeyNr;
  unsigned short KeyVersion;
  unsigned char Key[256];
}tSign;

#define MODULE_HEADER_ID 0x1077aa01

typedef enum{FILTER_NEUTRAL,FILTER_ALLOW,FILTER_BLOCK,FILTER_OVERLOADED}FILTER_RESULT;
typedef enum{INTEREST_RESULT_NO,INTEREST_RESULT_YES}INTEREST_RESULT;
typedef enum{CARD_STATE_UNKNOWN,CARD_STATE_NO,CARD_STATE_INSERTED,CARD_STATE_POWER_PRCCESS,CARD_STATE_POWERED,CARD_STATE_SPECIFIC,USER_BREAK}ISO_POWER;

#define APPL_ATTR_ENTRY               1
#define APPL_ATTR_HIGH_SEC            2
#define APPL_ATTR_AUTO_LED            4
#define APPL_ATTR_LIB                 8

#define APPL_FLAG_DEFAULT_ON_RESET    1

typedef void (*fctPowerUp)(void);
typedef void (*fctSwitchTo)(void);
typedef INTEREST_RESULT (*fctPostATRParser)(unsigned char *ATR,unsigned int ATRLen);
typedef FILTER_RESULT (*fctPreICCCmdFilter)(unsigned long ActiveModule,unsigned char *APDU,unsigned int APDULen);
typedef void (*fctPostCmdParser)(const unsigned char *APDU,unsigned int APDULen,const unsigned char *RAPDU,unsigned int RAPDULen);
typedef FILTER_RESULT (*fctPreIFDCmdFilter)(unsigned long ActiveModule,unsigned long ModuleID,unsigned short ModuleFkt,unsigned char *Input,unsigned int InputLen,unsigned short *OverloadFctNo);
typedef FILTER_RESULT (*fctAllowSwitch)(unsigned long ModuleID);
typedef void (*fctApplicationProcedure)(unsigned char *Input,unsigned int InputLen,unsigned char *Output,unsigned short *OutputLen,unsigned char *Error,unsigned short *ErrorLen);
typedef FILTER_RESULT (*fctCheckCoExistens)(unsigned int ModuleCount,unsigned long *IDs);
typedef int (*fctCheckCmdAndGetTexte)(unsigned char *cmd,unsigned int len,const char **Texte,unsigned int modi,const unsigned char **Symbol);
typedef void (*fctRecognizePINResult)(unsigned short SW1SW2);
typedef void (*fctRecognizeCardState)(ISO_POWER State);
typedef const char *(*fctGetApplicationStdText)(void);

typedef struct
{
  fctApplicationProcedure Procedure;
  unsigned long Attributes;
}tApplicationProcedure;

typedef struct
{
  unsigned long OffsetCrc16;
  unsigned long Status;
  unsigned long ModuleBaseAddr;
  unsigned long ModuleHeaderID;
  unsigned long ModuleID;
  unsigned long ModuleCodeSize;
  unsigned char Version;
  unsigned char Revision;
  unsigned char Variante;
  unsigned char RequieredKernelVersion;
  unsigned char RequieredKernelRevision;
  unsigned char GlobalHeapSize;
  unsigned char ExtraPages;
  unsigned char cReserved2;
  unsigned char DateOfCompilation[12];
  unsigned char TimeOfCompilation[12];
  char Description[16];
  fctPowerUp PowerUp;
  fctPostATRParser PostATRParser;
  fctPreICCCmdFilter PreICCCmdFilter;
  fctPreIFDCmdFilter PreIFDCmdFilter;
  fctPostCmdParser PostCmdParser;
  fctAllowSwitch AllowSwitch;
  const tApplicationProcedure *ApplicationProcedures;
  unsigned long ApplicationProcedureCount;
  unsigned long ApplicationFlags;
  fctSwitchTo SwitchTo;
  fctCheckCoExistens CheckCoExistens;
  fctCheckCmdAndGetTexte CheckCmdAndGetTexte;
  fctRecognizePINResult RecognizePINResult;
  fctRecognizeCardState RecognizeCardState;
  fctGetApplicationStdText GetApplicationStdText;
  unsigned long Reserved[31];
}tModuleHeader;

#define APPLICATION_START ((void *)0x00202800)
#define APPLICATION_DATA  0x00201C00
#define APPLICATION_DATA_SIZE  0x00000C00

#define KEY_DATA           0x00000600
#define GLOB_DATA          0x00000F00
#define CONF_DATA          0x00001000
#define KERNEL_HEADER_ADDR 0x00001200
#define KERNEL_EXPORTS_ADDR 0x00001400
#define KERNEL_UPDATE_ADDR 0x00020000

#define KERNEL_VERSION    0x30
#define KERNEL_REVISION   29

#define APPLICATION_HEADER_ADDR 0x00202700
#define CJECA_MAX_MODULES 16

#include "eca_defines.h"


#endif
