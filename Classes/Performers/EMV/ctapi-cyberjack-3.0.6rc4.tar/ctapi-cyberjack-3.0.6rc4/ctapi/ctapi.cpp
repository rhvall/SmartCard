/***************************************************************************
 $RCSfile$
                             -------------------
    cvs         : $Id: ctapi.cpp 2007-04-23 10:27:17Z martin $
    begin       : Mon Apr 23 2007
    copyright   : (C) 2007 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Lesser General Public            *
 *   License as published by the Free Software Foundation; either          *
 *   version 2.1 of the License, or (at your option) any later version.    *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *
 *   MA  02111-1307  USA                                                   *
 *                                                                         *
 ***************************************************************************/



#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include "stdafx.h"
#include "ctapi_beep.h"
#include "ctapi_config_l.h"
#include "version.h"

#include "ctapi-ecom.h"
#include "cjppa.h"

#include "ausb_l.h"
#include "usbdev_l.h"

#include <stdarg.h>
#include <list>
#include <string>

#include <sys/stat.h>
#include <pwd.h>
#include <sys/types.h>


#if 1
# define DEBUGP(ctn, format, args...) \
   rsct_log(ctn, DEBUG_MASK_CTAPI, __FILE__, __LINE__, __FUNCTION__, format, ## args)

# define DEBUGL(ctn, hdr, len, data) \
   rsct_log_bytes(ctn, DEBUG_MASK_CTAPI, __FILE__, __LINE__, __FUNCTION__, hdr, len, data)
#else
# define DEBUGP(ctn, format, args...)
# define DEBUGL(ctn, hdr, len, data)

#endif

struct Ctapi_Context {
  CReader *reader;
  CJ_INFO *oldEcom;
  CCID_DEVICE ppa;
  uint16_t ctn;
  uint16_t port;
  CT_KEY_CB keyCallback;
  void *kcb_user_data;
  std::string readerName;
  Ctapi_Context()
    :reader(NULL), oldEcom(NULL), ppa(NULL),
    keyCallback(NULL), kcb_user_data(NULL){}
  ~Ctapi_Context() {
    if (reader)
      delete reader;
  };
};


static int _ctapi_init_count=0;
static struct beep_struct *beepstruct = NULL;
static std::list<Ctapi_Context*> ct_context_list;



static void ctapi_LogAusb(ausb_dev_handle *ah,
			  const char *text,
			  const void *pData, uint32_t ulDataLen) {
  rsct_debug_out("<USB>",
		 DEBUG_MASK_COMMUNICATION_IN,
		 (char*)text,
		 (char*)pData, ulDataLen);
}



static Ctapi_Context *findContextByCtn(uint16_t ctn) {
  std::list<Ctapi_Context*>::iterator it;

  for (it=ct_context_list.begin();
       it!=ct_context_list.end();
       it++) {
    if ((*it)->ctn==ctn)
      return *it;
  }

  return NULL;
}



static Ctapi_Context *findContextByPort(uint16_t pn) {
  std::list<Ctapi_Context*>::iterator it;

  for (it=ct_context_list.begin();
       it!=ct_context_list.end();
       it++) {
    if ((*it)->port==pn)
      return *it;
  }

  return NULL;
}



static void oldEcomKeyCallback(struct cj_info *ci, int key) {
  Ctapi_Context *ctx;

  DEBUGP(CT_INVALID_CTN, "ECOM: Key=%d", key);

  ctx=findContextByCtn(ci->ctn);
  if (ctx==NULL) {
    DEBUGP(CT_INVALID_CTN, "Context not open");
  }
  else {
    if (ctx->keyCallback) {
      DEBUGP(ctx->ctn, "Calling user-defined callback");
      ctx->keyCallback(ctx->ctn, key, ctx->kcb_user_data);
    }
    else {
      DEBUGP(CT_INVALID_CTN, "No user-defined callback, beeping");
      if (beepstruct)
	beep_whatever(beepstruct);
      else {
	DEBUGP(CT_INVALID_CTN, "No beep struct?");
      }
    }
  }
}



static void ppaKeyCallback(CCID_CTX ccid, unsigned char status) {
  Ctapi_Context *ctx;

  DEBUGP(CT_INVALID_CTN, "PPA: Key=%d", status);

  ctx=(Ctapi_Context*)ccid;
  if (ctx->keyCallback) {
    int key;

    key=status; /* TODO: Translate status into key... */
    DEBUGP(ctx->ctn, "Calling user-defined callback");
    ctx->keyCallback(ctx->ctn, key, ctx->kcb_user_data);
  }
  else {
    DEBUGP(CT_INVALID_CTN, "No user-defined callback, beeping");
    if (beepstruct)
      beep_whatever(beepstruct);
    else {
      DEBUGP(CT_INVALID_CTN, "No beep struct?");
    }
  }

}



static int init() {
  /* init CTAPI configuration */
  if (_ctapi_init_count==0) {
    unsigned int nLevelMask=0;
    const char *s;

    if (config_init())
      return -1;

    /* only initialize beep_struct once */
    if (!(config_get_flags() & CT_FLAGS_NO_BEEP)) {
      DEBUGP(CT_INVALID_CTN, "beep init");
      beepstruct=beep_init();
    }

    /* generic debug */
    if (config_get_flags() &
	(CT_FLAGS_DEBUG_GENERIC |
	 CT_FLAGS_DEBUG_READER)) {
      nLevelMask|=
	DEBUG_MASK_RESULTS |
	DEBUG_MASK_COMMUNICATION_ERROR;
    }

    /* ECA debugging */
    if (config_get_flags() & CT_FLAGS_DEBUG_ECA) {
      nLevelMask|=
	DEBUG_MASK_INPUT |
	DEBUG_MASK_OUTPUT |
	DEBUG_MASK_TRANSLATION;
    }

    /* USB debug */
    if (config_get_flags() &
	(CT_FLAGS_DEBUG_AUSB |
	 CT_FLAGS_DEBUG_USB)) {
      nLevelMask|=
	DEBUG_MASK_COMMUNICATION_OUT |
	DEBUG_MASK_COMMUNICATION_IN |
	DEBUG_MASK_COMMUNICATION_ERROR |
	DEBUG_MASK_COMMUNICATION_INT;
    }

    /* misc debug */
    if (config_get_flags() & CT_FLAGS_DEBUG_CTAPI) {
      nLevelMask|=DEBUG_MASK_CTAPI;
    }
    if (config_get_flags() & CT_FLAGS_DEBUG_IFD) {
      nLevelMask|=DEBUG_MASK_IFD;
    }

    /* set resulting debug mask */
    Debug.setLevelMask(nLevelMask);

    /* set log file */
    s=config_get_debug_filename();
    if (s) {
      struct stat st;

      Debug.setLogFileName(s);

      /* check for log file size */
      if (stat(s, &st)==0) {
	if (st.st_size>CT_LOGFILE_LIMIT) {
	  if (truncate(s, 0)==0) {
	    DEBUGP(CT_INVALID_CTN, "Truncated log file");
	  }
	}
      }
    }

    ausb_set_log_fn(ctapi_LogAusb);

    s=config_get_serial_filename();
    if (s==0) {
      struct passwd *p;

      /* get home dir */
      p=getpwuid(geteuid());
      if (p) {
	char pbuf[256];

	if (strlen(p->pw_dir)<sizeof(pbuf)) {
	  strcpy(pbuf, p->pw_dir);
	  strncat(pbuf, "/cyberjack_serials", sizeof(pbuf)-1);
	  pbuf[sizeof(pbuf)-1]=0;
	  config_set_serial_filename(pbuf);
	}
      }
      endpwent();
    }

    DEBUGP(CT_INVALID_CTN,
	   "Initialised CTAPI library (%d.%d.%d.%d/%d.%d.%d)",
	   CYBERJACK_VERSION_MAJOR, CYBERJACK_VERSION_MINOR,
	   CYBERJACK_VERSION_PATCHLEVEL, CYBERJACK_VERSION_BUILD,
	   PVER_MAJOR, PVER_MINOR, PVER_PATCHLEVEL, PVER_BUILD);
  }
  _ctapi_init_count++;

  return 0;
}



static void fini() {
  /* fini CTAPI configuration */
  if (_ctapi_init_count>0) {
    _ctapi_init_count--;
    if (_ctapi_init_count==0) {
      DEBUGP(CT_INVALID_CTN, "Deinitializing CTAPI library");
      if (beepstruct) {
        beep_fini(beepstruct);
        beepstruct=NULL;
      }
      config_fini();
    }
  }
}



static void keyCallback(ctxPtr Context, uint8_t key) {
  struct Ctapi_Context *ctx;

  ctx=(struct Ctapi_Context*)Context;
  if (ctx && ctx->keyCallback) {
    DEBUGP(ctx->ctn, "Calling user-defined callback");
    ctx->keyCallback(ctx->ctn, key, ctx->kcb_user_data);
  }
  else {
    DEBUGP(CT_INVALID_CTN, "No user-defined callback, beeping");
    if (beepstruct)
      beep_whatever(beepstruct);
    else {
      DEBUGP(CT_INVALID_CTN, "No beep struct?");
    }
  }
}



extern "C" {


  static int8_t _init_common1(uint16_t ctn, uint16_t pn,
			      const char *dname){
    Ctapi_Context *ctx;
    std::string devName;
    int rv;
    CReader *r;

    if (init()) {
      fprintf(stderr, "Could not init CTAPI driver\n");
      return CT_API_RV_ERR_MEMORY;
    }

    if (rsct_enum_serials(config_get_serial_filename())) {
      fprintf(stderr, "RSCT: Could not enumerate readers\n");
    }

    DEBUGP(CT_INVALID_CTN, "ctn=%d, pn=%d, devName=%s",
	   ctn, pn, dname?dname:"none");
    if (ctn==CT_INVALID_CTN) {
      DEBUGP(CT_INVALID_CTN, "Invalid context id");
      fini();
      return -127;
    }

    ctx=findContextByCtn(ctn);
    if (ctx) {
      DEBUGP(CT_INVALID_CTN, "Context %d id already in use", ctn);
      Debug.Out("CTAPI",
		DEBUG_MASK_CTAPI,
		"Context already in use",0,0);
      fini();
      return -127;
    }

    if (pn) {
      if (findContextByPort(pn)) {
	DEBUGP(CT_INVALID_CTN, "Port %d already in use", pn);
	Debug.Out("CTAPI",
		  DEBUG_MASK_CTAPI,
		  "Port already in use",0,0);
	fini();
	return -127;
      }

      if (pn>=0xa000) {
	char *s;

	s=CSerialLinux::createDeviceName(pn-0xa000);
	if (s) {
	  devName=std::string(s);
	  free(s);
	}
	else {
	  DEBUGP(CT_INVALID_CTN, "Device %d not found", pn);
	  fini();
	  return -127;
	}
      }
      else if (pn>=0x9000) {
	char serial[128];
	int rv;

	rv=rsct_get_serial_for_port(pn-0x8fff,
				    config_get_serial_filename(),
				    serial, sizeof(serial)-1);
	if (rv!=0) {
	  DEBUGP(CT_INVALID_CTN, "Device %d not found", pn);
	  fini();
	  return -127;
	}
	else {
	  rsct_usbdev_t *devs=NULL;

	  rv=rsct_usbdev_scan(&devs);
	  if (rv<0) {
	    DEBUGP(CT_INVALID_CTN, "Could not scan (%d)", rv);
	    rsct_usbdev_list_free(devs);
	    fini();
	    return -10;
	  }
	  else {
	    rsct_usbdev_t *d;

	    /* find device with the given serial number */
	    d=devs;
	    while(d) {
	      if (d->vendorId==0xc4b &&
		  d->serial[0] &&
		  (strcasecmp(serial, d->serial)==0)) {
                break;
	      }
	      d=d->next;
	    }

	    if (d==NULL) {
	      DEBUGP(CT_INVALID_CTN, "Device %d [%s] not connected",
		     pn, serial);
	      rsct_usbdev_list_free(devs);
	      fini();
	      return -127;
	    }
	    else {
	      char ubuf[128];

	      snprintf(ubuf, sizeof(ubuf),
		       "usb:%04x/%04x:libusb:%03d:%03d",
		       d->vendorId,
		       d->productId,
		       d->busId,
		       d->busPos);

	      devName=std::string(ubuf);
	    }
	    rsct_usbdev_list_free(devs);
	  }
	}
      }
      else {
	char *s;

	s=CUSBLinux::createDeviceName(pn);
	if (s) {
	  devName=std::string(s);
          free(s);
	}
	else {
	  DEBUGP(CT_INVALID_CTN, "Device %d not found", pn);
	  fini();
	  return -127;
	}
      }
    }
    else {
      devName=std::string(dname);
    }

    DEBUGP(CT_INVALID_CTN, "Device path is: [%s]", devName.c_str());

    if (strstr(devName.c_str(), "0c4b/0100")) {
      CJ_INFO *ci;
      int rv;

      /* old cyberjack or ecom */
      rv=cjecom_CT_initUser2(ctn, devName.c_str(), &ci,
			    (config_get_flags() &
			     CT_FLAGS_NO_RESET_BEFORE)?0:1);
      if (rv)
	return rv;

      /* create context */
      ctx=new Ctapi_Context();
      ctx->oldEcom=ci;
      ctx->ctn=ctn;
      ctx->port=pn;
      ctx->keyCallback=NULL;
      ctx->readerName=devName;
      ct_context_list.push_back(ctx);

      /* set key callback */
      cjecom_CT_keycb(ci, oldEcomKeyCallback);

      DEBUGP(ctn, "Ecom/Cyberjack 0x100 detected at %d", pn);
    }
    else if (strstr(devName.c_str(), "0c4b/0300")) {
      CCID_DEVICE ccid;

      /* pre-create the context to be able to point to it */
      ctx=new Ctapi_Context();
      ctx->ctn=ctn;
      ctx->port=pn;
      ctx->keyCallback=NULL;
      ctx->readerName=devName;

      ccid=ctapiInit(devName.c_str(),
		     (CCID_CTX)ctx,
		     NULL, /* status callback */
		     ppaKeyCallback);
      if (ccid==NULL) {
	fprintf(stderr, "CTAPI: Could not open device at %d\n", pn);
        delete ctx;
	return -127;
      }
      ctx->ppa=ccid;
      ct_context_list.push_back(ctx);

      DEBUGP(ctn, "Cyberjack pinpad_a detected at %d", pn);
    }
    else {
      /* driven by new driver */
      r=new CReader(devName.c_str());
      rv=r->Connect();
      if (rv!=CJ_SUCCESS) {
	DEBUGP(CT_INVALID_CTN, "Unable to connect device %d", pn);
        delete r;
	fini();
	return -127;
      }
  
      ctx=new Ctapi_Context();
      ctx->reader=r;
      ctx->ctn=ctn;
      ctx->port=pn;
      ctx->keyCallback=NULL;
      ctx->readerName=devName;
      ct_context_list.push_back(ctx);
  
      r->SetKeyInterruptCallback(keyCallback, (ctxPtr) ctx);
  
      if (1) {
	CJ_RESULT res;
	cj_ReaderInfo ri;
  
	ri.SizeOfStruct=sizeof(ri);
	res=r->CtGetReaderInfo(&ri);
	if (res!=SCARD_S_SUCCESS) {
	  DEBUGP(ctn, "Reader info not available (%d)", rv);
	}
	else {
	  DEBUGP(ctn, "Reader info available:");
	  if (ri.ContentsMask & RSCT_READER_MASK_VERSION) {
	    DEBUGP(ctn, "Version: %x", ri.Version);
	  }
	  if (ri.ContentsMask & RSCT_READER_MASK_HARDWARE_VERSION) {
	    DEBUGP(ctn, "HW-Version: %d", ri.HardwareVersion);
	  }
	  if (ri.ContentsMask & RSCT_READER_MASK_SERIALNUMBER) {
	    DEBUGP(ctn, "SerialNumber: %s", ri.SeriaNumber);
	  }
	  if (ri.ContentsMask & RSCT_READER_MASK_PRODUCTION_DATE) {
	    DEBUGP(ctn, "Production Date: %s", ri.ProductionDate);
	  }
	  if (ri.ContentsMask & RSCT_READER_MASK_COMMISSIONING_DATE) {
	    DEBUGP(ctn, "Commission Date: %s", ri.CommissioningDate);
	  }
	  if (ri.ContentsMask & RSCT_READER_MASK_TEST_DATE) {
	    DEBUGP(ctn, "Test Date: %s", ri.TestDate);
	  }
	}
      }
    }

    return 0;
  }



  static int8_t _init_common2(uint16_t ctn, uint16_t pn,
			      const char *dname){
    int8_t rv;

    rv=_init_common1(ctn, pn, dname);
    if (rv==0) {
      uint8_t apdu[]={0x20, 0x13, 0x00, 0x46, 0x00};
      uint8_t responseBuffer[300];
      uint16_t lr;
      uint8_t sad, dad;

      lr=sizeof(responseBuffer);
      sad=CT_API_AD_HOST;
      dad=CT_API_AD_CT;
      rv=CT_data(ctn, &dad, &sad, 5, apdu, &lr, responseBuffer);
      if (rv) {
	DEBUGP(ctn, "Error retrieving reader information");
	CT_close(ctn);
        return rv;
      }
    }

    return rv;
  }



  int8_t CT_init(uint16_t ctn, uint16_t pn){
    if (pn==0) {
      DEBUGP(CT_INVALID_CTN, "Invalid port");
      return -127;
    }
    if (ctn==CT_INVALID_CTN) {
      DEBUGP(CT_INVALID_CTN, "Invalid context id");
      return -127;
    }
    return _init_common2(ctn, pn, NULL);
  }



  int8_t CT_data(uint16_t ctn,
		 uint8_t *dad,
		 uint8_t *sad,
		 uint16_t cmd_len,
		 const uint8_t *cmd,
		 uint16_t *response_len,
		 uint8_t *response){
    char res;
    Ctapi_Context *ctx;

    ctx=findContextByCtn(ctn);
    if (ctx==NULL) {
      DEBUGP(CT_INVALID_CTN, "Context %d not open", ctn);
      return -128;
    }

    if (ctx->oldEcom!=NULL) {
      DEBUGL(ctn, "Sending", cmd_len, cmd);
      res=cjecom_CT_data(ctx->oldEcom,
			 dad, sad,
			 cmd_len, cmd,
			 response_len, response);
      DEBUGP(ctn, "Result: %d", res);
      if (res==0) {
	DEBUGL(ctn, "Received", *response_len, response);
      }
    }
    else if (ctx->ppa!=NULL) {
      DEBUGL(ctn, "Sending", cmd_len, cmd);
      res=ctapiData(ctx->ppa,
		    dad, sad,
		    cmd_len, cmd,
		    response_len, response);
      DEBUGP(ctn, "Result: %d", res);
      if (res==0) {
	DEBUGL(ctn, "Received", *response_len, response);
      }
    }
    else if (ctx->reader!=NULL) {
      DEBUGL(ctn, "Sending", cmd_len, cmd);
      res=ctx->reader->CtData(dad,sad,cmd_len,cmd,response_len,response);
      DEBUGP(ctn, "Result: %d", res);
      if (res==0) {
	DEBUGL(ctn, "Received", *response_len, response);
      }
    }
    else {
      /* device lost */
      DEBUGP(ctn, "Device lost");
      return -127;
    }

    switch(res){
    case 0:
    case -1:
    case -11:
      break;
    default:
      if (ctx->reader) {
	delete ctx->reader;
	ctx->reader=NULL;
      }
      DEBUGP(ctn, "Device lost (rv=%d)", res);
      if (ctx->oldEcom) {
	cjecom_CT_close(ctx->oldEcom);
	free(ctx->oldEcom);
	ctx->oldEcom=NULL;
      }
      else if (ctx->ppa) {
	ctapiClose(ctx->ppa);
	ctx->ppa=NULL;
      }
    }

    return res;
  }



  int8_t CT_close(uint16_t ctn){
    Ctapi_Context *ctx;

    DEBUGP(CT_INVALID_CTN, "Closing device %d", ctn);
    ctx=findContextByCtn(ctn);
    if (ctx==NULL) {
      return -128;
    }

    if (ctx->oldEcom!=NULL) {
      cjecom_CT_close(ctx->oldEcom);
      free(ctx->oldEcom);
      ctx->oldEcom=NULL;
      ct_context_list.remove(ctx);
      delete ctx;
      fini();
      return 0;
    }
    else if (ctx->ppa!=NULL) {
      ctapiClose(ctx->ppa); /* gets freed there */
      ctx->oldEcom=NULL;
      ct_context_list.remove(ctx);
      delete ctx;
      fini();
      return 0;
    }
    else if (ctx->reader!=NULL) {
      ctx->reader->Disonnect();
      ct_context_list.remove(ctx);
      delete ctx;
      fini();
      return 0;
    }
    else {
      /* device lost */
      ct_context_list.remove(ctx);
      delete ctx;
      fini();
      return -127;
    }

  }



  int8_t rsct_setkeycb(uint16_t ctn, CT_KEY_CB cb, void *user_data) {
    Ctapi_Context *ctx;

    ctx=findContextByCtn(ctn);
    if (ctx==NULL) {
      Debug.Out("CTAPI",
		DEBUG_MASK_CTAPI,
		"Context not open",0,0);
      return -128;
    }

    if (ctx->reader==NULL &&
	ctx->oldEcom==NULL &&
	ctx->ppa==NULL) {
      /* device lost */
      Debug.Out("CTAPI",
		DEBUG_MASK_CTAPI,
		"Device lost",0,0);
      return -127;
    }

    ctx->keyCallback=cb;
    ctx->kcb_user_data=user_data;

    return CT_API_RV_OK;
  }



  int8_t rsct_init_name(uint16_t ctn, const char *devName) {
    DEBUGP(CT_INVALID_CTN, "Init device [%s]",
	   devName?devName:"<empty>");
    if (devName==NULL) {
      DEBUGP(CT_INVALID_CTN, "No device name given");
      return -127;
    }
    if (ctn==CT_INVALID_CTN) {
      DEBUGP(CT_INVALID_CTN, "Invalid context id");
      return -127;
    }

    return _init_common2(ctn, 0, devName);
  }



  void rsct_version(uint8_t *vmajor,
		    uint8_t *vminor,
		    uint8_t *vpatchlevel,
		    uint16_t *vbuild) {
    if (vmajor)
      *vmajor=CYBERJACK_VERSION_MAJOR;
    if (vminor)
      *vminor=CYBERJACK_VERSION_MINOR;
    if (vpatchlevel)
      *vpatchlevel=CYBERJACK_VERSION_PATCHLEVEL;
    if (vbuild)
      *vbuild=CYBERJACK_VERSION_BUILD;
  }



  void rsct_log(uint16_t ctn,
		unsigned int what,
		const char *file, int line, const char *function,
		const char *format, ...) {
    char tbuf[512];
    char *p;
    unsigned int len;
    va_list ap;
    unsigned int i;

    /* prefix */
    snprintf(tbuf, sizeof(tbuf)-1,
	     "%s:%s:%d:",
	     file, function, line);
    len=strlen(tbuf);
    p=tbuf+len;
    len=sizeof(tbuf)-len;

    /* real message */
    va_start(ap, format);
    vsnprintf(p, len-1, format, ap);
    va_end(ap);
    tbuf[sizeof(tbuf)-1]=0;

    len=strlen(tbuf);
    /* remove newline chars */
    for (i=0; i<len; i++) {
      if (tbuf[i]=='\n')
	tbuf[i]=' ';
    }

    /* output message */
    if (ctn!=CT_INVALID_CTN) {
      Ctapi_Context *ctx;

      ctx=findContextByCtn(ctn);
      if (ctx && ctx->reader)
	ctx->reader->DebugLeveled(what, tbuf, NULL, 0);
      else
	Debug.Out("LOG",
		  what,
		  tbuf, NULL, 0);
    }
    else
      Debug.Out("LOG",
                what,
		tbuf, NULL, 0);
  }



  void rsct_log_bytes(uint16_t ctn,
		      unsigned int what,
		      const char *file, int line,
		      const char *function,
		      const char *hdr,
		      int datalen, const uint8_t *data) {
    char tbuf[512];
    unsigned int i;
    unsigned int len;

    /* prefix */
    snprintf(tbuf, sizeof(tbuf)-1,
	     "%s:%s:%d:%s",
	     file, function, line, hdr);
    len=strlen(tbuf);

    /* remove newline chars */
    for (i=0; i<len; i++) {
      if (tbuf[i]=='\n')
	tbuf[i]=' ';
    }

    /* output message */
    if (ctn!=CT_INVALID_CTN) {
      Ctapi_Context *ctx;

      ctx=findContextByCtn(ctn);
      if (ctx)
	Debug.Out((char*)ctx->readerName.c_str(),
		  what, tbuf, (char*)data, datalen);
      else
	Debug.Out("LOG",
		  what, tbuf, (char*)data, datalen);
    }
    else
      Debug.Out("LOG",
		what, tbuf, (char*)data, datalen);
  }


} /* extern C */


