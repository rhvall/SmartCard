/***************************************************************************
 $RCSfile: cyberjack_l.h,v $
                             -------------------
    cvs         : $Id: cyberjack_l.h,v 1.3 2007/05/08 08:37:33 martin Exp $
    begin       : Mon Aug 14 2006
    copyright   : (C) 2006 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *                                                                         *
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Lesser General Public            *
 *   License as published by the Free Software Foundation; either          *
 *   version 2.1 of the License, or (at your option) any later version.    *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston,                 *
 *   MA  02111-1307  USA                                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef CYBERJACKAPI_H
#define CYBERJACKAPI_H

#include <inttypes.h>
#include <cjeca32.h>
#include <stdarg.h>


#define CT_MAX_DEVICES 256

#define CT_INVALID_CTN (0xffff)

#define CT_API_RV_OK		0
#define CT_API_RV_ERR_INVALID	-1
#define CT_API_RV_ERR_CT	-8
#define CT_API_RV_ERR_TRANS	-10
#define CT_API_RV_ERR_MEMORY	-11
#define CT_API_RV_ERR_HOST	-127
#define CT_API_RV_ERR_HTSI	-128

#define CT_API_AD_HOST		2
#define CT_API_AD_REMOTE	5

#define CT_API_AD_CT		1

#define CJ_CTAPI_MAX_LENC	(4+1+255+1)
#define CJ_CTAPI_MAX_LENR	(256+2)


#define CJ_KEY_DIGIT 1
#define CJ_KEY_CLEAR 2

#define CT_LOGFILE_LIMIT (10*1024*1024)


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @return <0 on error, 0 if reader should beep, 1 if this has been handled
 * by the callback function
 */
typedef int (*CT_KEY_CB)(uint16_t ctn,
                         int key,
			 void *user_data);

CJECA32_API
int8_t CT_init(uint16_t ctn, uint16_t pn);

CJECA32_API
int8_t CT_data(uint16_t ctn,
	       uint8_t *dad,
	       uint8_t *sad,
	       uint16_t cmd_len,
	       const uint8_t *cmd,
	       uint16_t *response_len,
	       uint8_t *response);

CJECA32_API
int8_t CT_close(uint16_t ctn);


CJECA32_API
int8_t rsct_setkeycb(uint16_t ctn, CT_KEY_CB cb, void *user_data);

CJECA32_API
int8_t rsct_init_name(uint16_t ctn, const char *devName);

CJECA32_API
void rsct_version(uint8_t *vmajor,
		  uint8_t *vminor,
		  uint8_t *vpatchlevel,
		  uint16_t *vbuild);


CJECA32_API
void rsct_log(uint16_t ctn,
	      unsigned int what,
	      const char *file, int line, const char *function,
	      const char *format, ...);
CJECA32_API
void rsct_vlog(uint16_t ctn,
	      unsigned int what,
	      const char *file, int line, const char *function,
	      const char *format, va_list args);

CJECA32_API
void rsct_log_bytes(uint16_t ctn,
		    unsigned int what,
		    const char *file, int line,
		    const char *function,
		    const char *hdr,
		    int datalen, const uint8_t *data);

#ifdef __cplusplus
}
#endif


#endif


