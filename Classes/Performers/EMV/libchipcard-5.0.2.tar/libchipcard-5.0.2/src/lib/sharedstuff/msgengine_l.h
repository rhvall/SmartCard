/***************************************************************************
    begin       : Mon Mar 01 2004
    copyright   : (C) 2004-2010 by Martin Preuss
    email       : martin@libchipcard.de

 ***************************************************************************
 *          Please see toplevel file COPYING for license details           *
 ***************************************************************************/


#ifndef CHIPCARD2_MSGENGINE_L_H
#define CHIPCARD2_MSGENGINE_L_H

#include <gwenhywfar/msgengine.h>
#include "msgengine.h"


#endif /* CHIPCARD2_MSGENGINE_L_H */


